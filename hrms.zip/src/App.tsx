import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext.js';
import { NotificationProvider } from './context/NotificationContext.js';
import { ProtectedRoute } from './components/common/ProtectedRoute.js';
import { AppShell } from './components/shell/AppShell.js';

// Auth Pages
import { LoginPage } from './pages/auth/LoginPage.js';
import { ForgotPasswordPage } from './pages/auth/ForgotPasswordPage.js';

// Application Pages
import { DashboardPage } from './pages/dashboard/DashboardPage.js';
import { CompaniesPage } from './pages/organization/CompaniesPage.js';
import { BranchesPage } from './pages/organization/BranchesPage.js';
import { DepartmentsPage } from './pages/organization/DepartmentsPage.js';
import { DesignationsPage } from './pages/organization/DesignationsPage.js';
import { WorkLocationsPage } from './pages/organization/WorkLocationsPage.js';
import { HolidaysPage } from './pages/organization/HolidaysPage.js';

// Employee Module (Phase 1C)
import { EmployeeDirectoryPage } from './pages/employees/EmployeeDirectoryPage.js';
import { AddEmployeeWizardPage } from './pages/employees/AddEmployeeWizardPage.js';
import { EmployeeProfilePage } from './pages/employees/EmployeeProfilePage.js';

// Attendance & Shift Management (Phase 2A & 2B)
import { ShiftManagementPage } from './pages/attendance/ShiftManagementPage.js';
import { DailyAttendancePage } from './pages/attendance/DailyAttendancePage.js';
import { MonthlyAttendancePage } from './pages/attendance/MonthlyAttendancePage.js';
import { MyAttendancePage } from './pages/attendance/MyAttendancePage.js';
import { AttendanceRegularizationPage } from './pages/attendance/AttendanceRegularizationPage.js';

// Admin Pages
import { UserManagementPage } from './pages/admin/UserManagementPage.js';
import { RolesPermissionsPage } from './pages/admin/RolesPermissionsPage.js';
import { SystemSettingsPage } from './pages/admin/SystemSettingsPage.js';
import { AuditLogPage } from './pages/admin/AuditLogPage.js';

// Approvals & Reports
import { ApprovalInboxPage } from './pages/approvals/ApprovalInboxPage.js';
import { ReportCenterPage } from './pages/reports/ReportCenterPage.js';

// Common Pages
import { UnauthorizedPage } from './pages/common/UnauthorizedPage.js';
import { NotFoundPage } from './pages/common/NotFoundPage.js';
import { RoutePlaceholder } from './components/common/RoutePlaceholder.js';

import { PermissionKey } from './types/auth.js';

export default function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <BrowserRouter>
          <Routes>
            {/* Public Unauthenticated Routes */}
            <Route path="/login" element={<LoginPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            <Route path="/unauthorized" element={<UnauthorizedPage />} />

            {/* Main Application Shell Layout */}
            <Route
              element={
                <ProtectedRoute>
                  <AppShell />
                </ProtectedRoute>
              }
            >
              {/* Root Redirect to Dashboard */}
              <Route path="/" element={<Navigate to="/dashboard" replace />} />

              {/* Dashboard */}
              <Route path="/dashboard" element={<DashboardPage />} />

              {/* Organization Module */}
              <Route
                path="/organization/companies"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ORGANIZATION_VIEW}>
                    <CompaniesPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/organization/branches"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ORGANIZATION_VIEW}>
                    <BranchesPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/organization/departments"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ORGANIZATION_VIEW}>
                    <DepartmentsPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/organization/designations"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ORGANIZATION_VIEW}>
                    <DesignationsPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/organization/work-locations"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ORGANIZATION_VIEW}>
                    <WorkLocationsPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/organization/locations"
                element={<Navigate to="/organization/work-locations" replace />}
              />
              <Route
                path="/organization/holidays"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ORGANIZATION_VIEW}>
                    <HolidaysPage />
                  </ProtectedRoute>
                }
              />

              {/* Administration Module */}
              <Route
                path="/administration/users"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ADMIN_USERS_MANAGE}>
                    <UserManagementPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/administration/roles"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ADMIN_ROLES_MANAGE}>
                    <RolesPermissionsPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/administration/settings"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ADMIN_SETTINGS_MANAGE}>
                    <SystemSettingsPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/administration/audit"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ADMIN_AUDIT_VIEW}>
                    <AuditLogPage />
                  </ProtectedRoute>
                }
              />

              {/* Admin legacy route redirects */}
              <Route path="/admin/users" element={<Navigate to="/administration/users" replace />} />
              <Route path="/admin/roles" element={<Navigate to="/administration/roles" replace />} />
              <Route path="/admin/settings" element={<Navigate to="/administration/settings" replace />} />
              <Route path="/admin/audit" element={<Navigate to="/administration/audit" replace />} />

              {/* Approval Inbox & Reports */}
              <Route path="/approvals" element={<ApprovalInboxPage />} />
              <Route
                path="/reports"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.REPORTS_VIEW}>
                    <ReportCenterPage />
                  </ProtectedRoute>
                }
              />

              {/* Employee Module Routes (Phase 1C) */}
              <Route
                path="/employees"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.EMPLOYEE_VIEW}>
                    <EmployeeDirectoryPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/employees/new"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.EMPLOYEE_MANAGE}>
                    <AddEmployeeWizardPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/employees/:id"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.EMPLOYEE_VIEW}>
                    <EmployeeProfilePage />
                  </ProtectedRoute>
                }
              />

              {/* Attendance & Shift Management Routes (Phase 2A & 2B) */}
              <Route
                path="/attendance/daily"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ATTENDANCE_VIEW}>
                    <DailyAttendancePage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/attendance/monthly"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ATTENDANCE_VIEW}>
                    <MonthlyAttendancePage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/attendance/my-attendance"
                element={<MyAttendancePage />}
              />
              <Route
                path="/me/attendance"
                element={<MyAttendancePage />}
              />
              <Route
                path="/attendance/regularizations"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ATTENDANCE_VIEW}>
                    <AttendanceRegularizationPage />
                  </ProtectedRoute>
                }
              />
              <Route path="/attendance/regularization" element={<Navigate to="/attendance/regularizations" replace />} />
              <Route
                path="/attendance/shifts"
                element={
                  <ProtectedRoute requiredPermission={PermissionKey.ATTENDANCE_VIEW}>
                    <ShiftManagementPage />
                  </ProtectedRoute>
                }
              />
              <Route path="/attendance" element={<Navigate to="/attendance/daily" replace />} />
              <Route
                path="/leave/*"
                element={
                  <RoutePlaceholder
                    title="Leave Management Module"
                    description="Phase 3 scope — Accrual rules, leave applications & encashment."
                  />
                }
              />
              <Route
                path="/payroll/*"
                element={
                  <RoutePlaceholder
                    title="Payroll & Compensation Module"
                    description="Phase 4 scope — Salary structures, tax compliance & payslip generation."
                  />
                }
              />
              <Route
                path="/me/*"
                element={
                  <RoutePlaceholder
                    title="Employee Self Service (ESS)"
                    description="Phase 1-3 scope — My Profile, Attendance Punches, Leave Requests & Payslips."
                  />
                }
              />
              <Route
                path="/recruitment/*"
                element={
                  <RoutePlaceholder
                    title="Recruitment & Applicant Tracking"
                    description="Phase 5 scope — Job postings, candidate pipeline & interview evaluation."
                  />
                }
              />
              <Route
                path="/onboarding/*"
                element={
                  <RoutePlaceholder
                    title="Onboarding Checklists"
                    description="Phase 5 scope — New hire welcome workflow, document collection & tasks."
                  />
                }
              />
              <Route
                path="/performance/*"
                element={
                  <RoutePlaceholder
                    title="Performance Management"
                    description="Phase 5 scope — Review cycles, 360 feedback, goals & KPI tracking."
                  />
                }
              />
              <Route
                path="/expenses/*"
                element={
                  <RoutePlaceholder
                    title="Expense Claims"
                    description="Phase 5 scope — Travel & expense claim submissions and approvals."
                  />
                }
              />
              <Route
                path="/assets/*"
                element={
                  <RoutePlaceholder
                    title="Asset Management"
                    description="Phase 5 scope — Hardware & software asset allocation and tracking."
                  />
                }
              />
              <Route
                path="/offboarding/*"
                element={
                  <RoutePlaceholder
                    title="Exit & Offboarding"
                    description="Phase 5 scope — Resignation processing, exit interview & clearance."
                  />
                }
              />
            </Route>

            {/* 404 Catch All */}
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </BrowserRouter>
      </NotificationProvider>
    </AuthProvider>
  );
}
