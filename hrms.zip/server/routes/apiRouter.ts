import { Router, Response, NextFunction } from 'express';
import { AuthService } from '../services/AuthService.js';
import { OrganizationService, ServiceActor } from '../services/OrganizationService.js';
import { AuditService } from '../services/AuditService.js';
import { EmployeeService } from '../services/EmployeeService.js';
import { ShiftService } from '../services/ShiftService.js';
import { AttendanceService } from '../services/AttendanceService.js';
import { authMiddleware, AuthenticatedRequest, requirePermission } from '../middleware/authMiddleware.js';
import { PermissionKey, UserRole } from '../../src/types/auth.js';

export const apiRouter = Router();

// Ensure all API responses default to JSON
apiRouter.use((_req, res: Response, next: NextFunction) => {
  res.setHeader('Content-Type', 'application/json');
  next();
});

/**
 * Helper to extract actor from request
 */
function getActor(req: AuthenticatedRequest): ServiceActor {
  return {
    id: req.user?.id || 'anonymous',
    name: req.user?.fullName || 'Anonymous User',
    email: req.user?.email || 'anonymous@hrms.enterprise.com',
    role: req.user?.role || 'GUEST',
    ipAddress: req.ip || req.socket.remoteAddress || '127.0.0.1',
  };
}

/**
 * PUBLIC AUTHENTICATION ENDPOINTS (No token required)
 */
apiRouter.post('/auth/login', async (req: AuthenticatedRequest, res: Response) => {
  const { username, password } = req.body;
  if (!username) {
    return res.status(400).json({
      success: false,
      error: 'Username or email identifier is required for authentication.',
      code: 'MISSING_CREDENTIALS',
    });
  }

  const user = await AuthService.authenticate(username, password);
  if (!user) {
    if (username) {
      await AuditService.log({
        actorId: 'anonymous',
        actorName: username,
        actorEmail: `${username}@hrms.enterprise.com`,
        action: 'LOGIN_FAILURE',
        targetModule: 'Authentication',
        companyId: 'ALL',
        changesSummary: `Failed authentication attempt for username '${username}'.`,
      });
    }

    return res.status(401).json({
      success: false,
      error: 'Invalid credentials provided. Authentication failed.',
      code: 'INVALID_CREDENTIALS',
    });
  }

  const ipAddress = (req.ip || req.socket.remoteAddress || '127.0.0.1') as string;
  const userAgent = req.headers['user-agent'] as string | undefined;
  const { sessionId, token } = await AuthService.createSession(user.id, { ipAddress, userAgent });

  await AuditService.log({
    actorId: user.id,
    actorName: user.fullName,
    actorEmail: user.email,
    action: 'LOGIN_SUCCESS',
    targetModule: 'Authentication',
    companyId: user.activeCompanyId,
    changesSummary: `User authenticated successfully with role ${user.role} (Session ${sessionId}).`,
  });

  return res.json({
    success: true,
    data: {
      token,
      sessionId,
      user,
    },
  });
});

// PROTECTED ROUTES: Apply auth middleware to all subsequent /api/v1 routes
apiRouter.use(authMiddleware);

/**
 * PROTECTED AUTHENTICATION ENDPOINTS
 */
apiRouter.post('/auth/logout', async (req: AuthenticatedRequest, res: Response) => {
  if (req.sessionId) {
    await AuthService.revokeSession(req.sessionId);
  }

  if (req.user) {
    await AuditService.log({
      actorId: req.user.id,
      actorName: req.user.fullName,
      actorEmail: req.user.email,
      action: 'LOGOUT',
      targetModule: 'Authentication',
      companyId: req.user.activeCompanyId,
      changesSummary: `User logged out and session revoked.`,
    });
  }

  return res.json({
    success: true,
    message: 'Logged out successfully and server session revoked.',
  });
});

apiRouter.get('/auth/me', (req: AuthenticatedRequest, res: Response) => {
  return res.json({ success: true, data: req.user });
});

// =========================================================================
// 1. COMPANIES ENDPOINTS
// =========================================================================
apiRouter.get('/organization/companies', requirePermission(PermissionKey.ORGANIZATION_VIEW), async (req: AuthenticatedRequest, res: Response) => {
  const allCompanies = await OrganizationService.getCompanies();
  if (req.user?.role === UserRole.SUPER_ADMIN) {
    return res.json({ success: true, data: allCompanies });
  }
  const permitted = allCompanies.filter((c) => req.user?.companyIds.includes(c.id));
  return res.json({ success: true, data: permitted });
});

apiRouter.get('/organization/companies/:id', requirePermission(PermissionKey.ORGANIZATION_VIEW), async (req: AuthenticatedRequest, res: Response) => {
  const company = await OrganizationService.getCompanyById(req.params.id);
  if (!company) {
    return res.status(404).json({ success: false, error: 'Company not found.', code: 'NOT_FOUND' });
  }
  if (req.user?.role !== UserRole.SUPER_ADMIN && !req.user?.companyIds.includes(company.id)) {
    return res.status(403).json({ success: false, error: 'Forbidden: Access to this company is restricted.', code: 'COMPANY_ACCESS_DENIED' });
  }
  return res.json({ success: true, data: company });
});

apiRouter.post('/organization/companies', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const actor = getActor(req);
    const created = await OrganizationService.createCompany(req.body, actor);
    return res.status(201).json({ success: true, data: created });
  } catch (err) {
    next(err);
  }
});

apiRouter.put('/organization/companies/:id', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const actor = getActor(req);
    const updated = await OrganizationService.updateCompany(req.params.id, req.body, actor);
    return res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

apiRouter.patch('/organization/companies/:id/status', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const actor = getActor(req);
    const { status } = req.body;
    if (status !== 'ACTIVE' && status !== 'INACTIVE') {
      return res.status(400).json({ success: false, error: "Status must be either 'ACTIVE' or 'INACTIVE'.", code: 'VALIDATION_ERROR' });
    }
    const updated = await OrganizationService.toggleCompanyStatus(req.params.id, status, actor);
    return res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

// =========================================================================
// 2. BRANCHES ENDPOINTS (Tenant Isolated)
// =========================================================================
apiRouter.get('/organization/branches', requirePermission(PermissionKey.ORGANIZATION_VIEW), async (req: AuthenticatedRequest, res: Response) => {
  const companyId = req.user?.activeCompanyId || 'comp-101';
  const { search, status } = req.query;
  const branches = await OrganizationService.getBranches(
    companyId,
    typeof search === 'string' ? search : undefined,
    status === 'ACTIVE' || status === 'INACTIVE' ? status : undefined
  );
  return res.json({ success: true, data: branches });
});

apiRouter.get('/organization/branches/:id', requirePermission(PermissionKey.ORGANIZATION_VIEW), async (req: AuthenticatedRequest, res: Response) => {
  const companyId = req.user?.activeCompanyId || 'comp-101';
  const branch = await OrganizationService.getBranchById(req.params.id, companyId);
  if (!branch) {
    return res.status(404).json({ success: false, error: 'Branch not found in current company.', code: 'NOT_FOUND' });
  }
  return res.json({ success: true, data: branch });
});

apiRouter.post('/organization/branches', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const created = await OrganizationService.createBranch(req.body, companyId, actor);
    return res.status(201).json({ success: true, data: created });
  } catch (err) {
    next(err);
  }
});

apiRouter.put('/organization/branches/:id', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const updated = await OrganizationService.updateBranch(req.params.id, req.body, companyId, actor);
    return res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

apiRouter.patch('/organization/branches/:id/status', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const { status } = req.body;
    if (status !== 'ACTIVE' && status !== 'INACTIVE') {
      return res.status(400).json({ success: false, error: "Status must be either 'ACTIVE' or 'INACTIVE'.", code: 'VALIDATION_ERROR' });
    }
    const updated = await OrganizationService.toggleBranchStatus(req.params.id, status, companyId, actor);
    return res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

// =========================================================================
// 3. DEPARTMENTS ENDPOINTS (Tenant Isolated)
// =========================================================================
apiRouter.get('/organization/departments', requirePermission(PermissionKey.ORGANIZATION_VIEW), async (req: AuthenticatedRequest, res: Response) => {
  const companyId = req.user?.activeCompanyId || 'comp-101';
  const { search, status } = req.query;
  const departments = await OrganizationService.getDepartments(
    companyId,
    typeof search === 'string' ? search : undefined,
    status === 'ACTIVE' || status === 'INACTIVE' ? status : undefined
  );
  return res.json({ success: true, data: departments });
});

apiRouter.get('/organization/departments/:id', requirePermission(PermissionKey.ORGANIZATION_VIEW), async (req: AuthenticatedRequest, res: Response) => {
  const companyId = req.user?.activeCompanyId || 'comp-101';
  const dept = await OrganizationService.getDepartmentById(req.params.id, companyId);
  if (!dept) {
    return res.status(404).json({ success: false, error: 'Department not found in current company.', code: 'NOT_FOUND' });
  }
  return res.json({ success: true, data: dept });
});

apiRouter.post('/organization/departments', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const created = await OrganizationService.createDepartment(req.body, companyId, actor);
    return res.status(201).json({ success: true, data: created });
  } catch (err) {
    next(err);
  }
});

apiRouter.put('/organization/departments/:id', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const updated = await OrganizationService.updateDepartment(req.params.id, req.body, companyId, actor);
    return res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

apiRouter.patch('/organization/departments/:id/status', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const { status } = req.body;
    if (status !== 'ACTIVE' && status !== 'INACTIVE') {
      return res.status(400).json({ success: false, error: "Status must be either 'ACTIVE' or 'INACTIVE'.", code: 'VALIDATION_ERROR' });
    }
    const updated = await OrganizationService.toggleDepartmentStatus(req.params.id, status, companyId, actor);
    return res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

// =========================================================================
// 4. DESIGNATIONS ENDPOINTS (Tenant Isolated)
// =========================================================================
apiRouter.get('/organization/designations', requirePermission(PermissionKey.ORGANIZATION_VIEW), async (req: AuthenticatedRequest, res: Response) => {
  const companyId = req.user?.activeCompanyId || 'comp-101';
  const { search, status } = req.query;
  const designations = await OrganizationService.getDesignations(
    companyId,
    typeof search === 'string' ? search : undefined,
    status === 'ACTIVE' || status === 'INACTIVE' ? status : undefined
  );
  return res.json({ success: true, data: designations });
});

apiRouter.get('/organization/designations/:id', requirePermission(PermissionKey.ORGANIZATION_VIEW), async (req: AuthenticatedRequest, res: Response) => {
  const companyId = req.user?.activeCompanyId || 'comp-101';
  const desig = await OrganizationService.getDesignationById(req.params.id, companyId);
  if (!desig) {
    return res.status(404).json({ success: false, error: 'Designation not found in current company.', code: 'NOT_FOUND' });
  }
  return res.json({ success: true, data: desig });
});

apiRouter.post('/organization/designations', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const created = await OrganizationService.createDesignation(req.body, companyId, actor);
    return res.status(201).json({ success: true, data: created });
  } catch (err) {
    next(err);
  }
});

apiRouter.put('/organization/designations/:id', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const updated = await OrganizationService.updateDesignation(req.params.id, req.body, companyId, actor);
    return res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

// =========================================================================
// 5. WORK LOCATIONS ENDPOINTS (Tenant Isolated)
// =========================================================================
const getWorkLocationsHandler = async (req: AuthenticatedRequest, res: Response) => {
  const companyId = req.user?.activeCompanyId || 'comp-101';
  const { search, status, branchId } = req.query;
  const locations = await OrganizationService.getWorkLocations(
    companyId,
    typeof search === 'string' ? search : undefined,
    status === 'ACTIVE' || status === 'INACTIVE' ? status : undefined,
    typeof branchId === 'string' ? branchId : undefined
  );
  return res.json({ success: true, data: locations });
};

apiRouter.get('/organization/work-locations', requirePermission(PermissionKey.ORGANIZATION_VIEW), getWorkLocationsHandler);
apiRouter.get('/organization/locations', requirePermission(PermissionKey.ORGANIZATION_VIEW), getWorkLocationsHandler);

apiRouter.get('/organization/work-locations/:id', requirePermission(PermissionKey.ORGANIZATION_VIEW), async (req: AuthenticatedRequest, res: Response) => {
  const companyId = req.user?.activeCompanyId || 'comp-101';
  const loc = await OrganizationService.getWorkLocationById(req.params.id, companyId);
  if (!loc) {
    return res.status(404).json({ success: false, error: 'Work location not found in current company.', code: 'NOT_FOUND' });
  }
  return res.json({ success: true, data: loc });
});

apiRouter.post('/organization/work-locations', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const created = await OrganizationService.createWorkLocation(req.body, companyId, actor);
    return res.status(201).json({ success: true, data: created });
  } catch (err) {
    next(err);
  }
});

apiRouter.put('/organization/work-locations/:id', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const updated = await OrganizationService.updateWorkLocation(req.params.id, req.body, companyId, actor);
    return res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

// =========================================================================
// 6. HOLIDAYS ENDPOINTS (Tenant Isolated)
// =========================================================================
apiRouter.get('/organization/holidays', requirePermission(PermissionKey.ORGANIZATION_VIEW), async (req: AuthenticatedRequest, res: Response) => {
  const companyId = req.user?.activeCompanyId || 'comp-101';
  const { year, workLocationId, search, status } = req.query;
  const parsedYear = year ? parseInt(year as string, 10) : undefined;
  const holidays = await OrganizationService.getHolidays(
    companyId,
    isNaN(parsedYear as number) ? undefined : parsedYear,
    typeof workLocationId === 'string' ? workLocationId : undefined,
    typeof search === 'string' ? search : undefined,
    status === 'ACTIVE' || status === 'INACTIVE' ? status : undefined
  );
  return res.json({ success: true, data: holidays });
});

apiRouter.get('/organization/holidays/:id', requirePermission(PermissionKey.ORGANIZATION_VIEW), async (req: AuthenticatedRequest, res: Response) => {
  const companyId = req.user?.activeCompanyId || 'comp-101';
  const holiday = await OrganizationService.getHolidayById(req.params.id, companyId);
  if (!holiday) {
    return res.status(404).json({ success: false, error: 'Holiday not found in current company.', code: 'NOT_FOUND' });
  }
  return res.json({ success: true, data: holiday });
});

apiRouter.post('/organization/holidays', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const created = await OrganizationService.createHoliday(req.body, companyId, actor);
    return res.status(201).json({ success: true, data: created });
  } catch (err) {
    next(err);
  }
});

apiRouter.put('/organization/holidays/:id', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const updated = await OrganizationService.updateHoliday(req.params.id, req.body, companyId, actor);
    return res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

apiRouter.delete('/organization/holidays/:id', requirePermission(PermissionKey.ORGANIZATION_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    await OrganizationService.deleteHoliday(req.params.id, companyId, actor);
    return res.json({ success: true, message: 'Holiday deleted successfully.' });
  } catch (err) {
    next(err);
  }
});

// =========================================================================
// 7. EMPLOYEE CORE ENDPOINTS (Phase 1C)
// =========================================================================

// Employee Directory Listing with Filtering, Sorting & Pagination
apiRouter.get('/employees', requirePermission(PermissionKey.EMPLOYEE_VIEW), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const {
      search,
      branchId,
      departmentId,
      designationId,
      workLocationId,
      employmentType,
      status,
      managerId,
      page,
      limit,
      sortBy,
      sortOrder,
    } = req.query;

    const result = await EmployeeService.getDirectory(
      companyId,
      {
        search: typeof search === 'string' ? search : undefined,
        branchId: typeof branchId === 'string' ? branchId : undefined,
        departmentId: typeof departmentId === 'string' ? departmentId : undefined,
        designationId: typeof designationId === 'string' ? designationId : undefined,
        workLocationId: typeof workLocationId === 'string' ? workLocationId : undefined,
        employmentType: typeof employmentType === 'string' ? (employmentType as any) : undefined,
        status: typeof status === 'string' ? (status as any) : undefined,
        managerId: typeof managerId === 'string' ? managerId : undefined,
        page: page ? parseInt(page as string, 10) : 1,
        limit: limit ? parseInt(limit as string, 10) : 50,
        sortBy: typeof sortBy === 'string' ? sortBy : 'employeeCode',
        sortOrder: sortOrder === 'desc' ? 'desc' : 'asc',
      },
      req.user!
    );

    return res.json({
      success: true,
      data: result.items,
      total: result.total,
      page: page ? parseInt(page as string, 10) : 1,
      limit: limit ? parseInt(limit as string, 10) : 50,
    });
  } catch (err) {
    next(err);
  }
});

// Candidate Managers Dropdown for Selection
apiRouter.get('/employees/managers/options', requirePermission(PermissionKey.EMPLOYEE_VIEW), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const { excludeId } = req.query;
    const managers = await EmployeeService.getManagerOptions(
      companyId,
      typeof excludeId === 'string' ? excludeId : undefined
    );
    return res.json({ success: true, data: managers });
  } catch (err) {
    next(err);
  }
});

// Get Full Comprehensive Employee Profile
apiRouter.get('/employees/:id', requirePermission(PermissionKey.EMPLOYEE_VIEW), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const profile = await EmployeeService.getProfile(req.params.id, companyId, req.user!);
    if (!profile) {
      return res.status(404).json({
        success: false,
        error: 'Employee profile not found in current company.',
        code: 'NOT_FOUND',
      });
    }
    return res.json({ success: true, data: profile });
  } catch (err) {
    next(err);
  }
});

// Add Employee Transactional Creation
apiRouter.post('/employees', requirePermission(PermissionKey.EMPLOYEE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const profile = await EmployeeService.createEmployee(req.body, companyId, req.user!);
    return res.status(201).json({ success: true, data: profile });
  } catch (err) {
    next(err);
  }
});

// Update Employee Profile
apiRouter.put('/employees/:id', requirePermission(PermissionKey.EMPLOYEE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const profile = await EmployeeService.updateEmployee(req.params.id, req.body, companyId, req.user!);
    return res.json({ success: true, data: profile });
  } catch (err) {
    next(err);
  }
});

// Create Effective-Dated Organization Assignment Change (Transfer / Promotion / Manager change)
apiRouter.post('/employees/:id/assignments', requirePermission(PermissionKey.EMPLOYEE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const profile = await EmployeeService.createAssignmentChange(req.params.id, req.body, companyId, req.user!);
    return res.json({ success: true, data: profile });
  } catch (err) {
    next(err);
  }
});

// Update Employment Status
apiRouter.patch('/employees/:id/status', requirePermission(PermissionKey.EMPLOYEE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const profile = await EmployeeService.updateStatus(req.params.id, req.body, companyId, req.user!);
    return res.json({ success: true, data: profile });
  } catch (err) {
    next(err);
  }
});

// Document Upload Metadata
apiRouter.post('/employees/:id/documents', requirePermission(PermissionKey.EMPLOYEE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const doc = await EmployeeService.uploadDocument(req.params.id, req.body, companyId, req.user!);
    return res.status(201).json({ success: true, data: doc });
  } catch (err) {
    next(err);
  }
});

// Document Verification
apiRouter.patch('/employees/:id/documents/:docId/verify', requirePermission(PermissionKey.EMPLOYEE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const { status, notes } = req.body;
    if (status !== 'VERIFIED' && status !== 'REJECTED') {
      return res.status(400).json({ success: false, error: "Status must be 'VERIFIED' or 'REJECTED'.", code: 'VALIDATION_ERROR' });
    }
    const doc = await EmployeeService.verifyDocument(req.params.docId, req.params.id, status, notes, companyId, req.user!);
    return res.json({ success: true, data: doc });
  } catch (err) {
    next(err);
  }
});

// Delete Document
apiRouter.delete('/employees/:id/documents/:docId', requirePermission(PermissionKey.EMPLOYEE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    await EmployeeService.deleteDocument(req.params.docId, req.params.id, companyId, req.user!);
    return res.json({ success: true, message: 'Document deleted successfully.' });
  } catch (err) {
    next(err);
  }
});

// Download Document (Mock binary download stream or metadata)
apiRouter.get('/employees/:id/documents/:docId/download', requirePermission(PermissionKey.EMPLOYEE_VIEW), async (req: AuthenticatedRequest, res: Response) => {
  res.setHeader('Content-Type', 'text/plain');
  res.setHeader('Content-Disposition', `attachment; filename="document-${req.params.docId}.txt"`);
  return res.send(`HRMS Secure Document Download Payload - ID: ${req.params.docId}`);
});

// =========================================================================
// PHASE 2A: SHIFT MANAGEMENT & EMPLOYEE SHIFT ASSIGNMENTS
// =========================================================================

// 1. Shift Summary Metrics
apiRouter.get('/attendance/shifts/summary', requirePermission(PermissionKey.ATTENDANCE_VIEW), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const summary = await ShiftService.getShiftSummary(companyId);
    return res.json({ success: true, data: summary });
  } catch (err) {
    next(err);
  }
});

// 2. List Shifts
apiRouter.get('/attendance/shifts', requirePermission(PermissionKey.ATTENDANCE_VIEW), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const { search, status, isOvernight } = req.query;
    const filter = {
      search: search ? String(search) : undefined,
      status: status ? (String(status) as any) : undefined,
      isOvernight: isOvernight !== undefined ? isOvernight === 'true' : undefined,
    };
    const shifts = await ShiftService.getShifts(companyId, filter);
    return res.json({ success: true, data: shifts });
  } catch (err) {
    next(err);
  }
});

// 3. Get Shift by ID
apiRouter.get('/attendance/shifts/:id', requirePermission(PermissionKey.ATTENDANCE_VIEW), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const shift = await ShiftService.getShiftById(req.params.id, companyId);
    if (!shift) {
      return res.status(404).json({ success: false, error: 'Shift not found in current company context.', code: 'SHIFT_NOT_FOUND' });
    }
    return res.json({ success: true, data: shift });
  } catch (err) {
    next(err);
  }
});

// 4. Create Shift
apiRouter.post('/attendance/shifts', requirePermission(PermissionKey.ATTENDANCE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const created = await ShiftService.createShift(req.body, companyId, actor);
    return res.status(201).json({ success: true, data: created });
  } catch (err) {
    next(err);
  }
});

// 5. Update Shift
apiRouter.put('/attendance/shifts/:id', requirePermission(PermissionKey.ATTENDANCE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const updated = await ShiftService.updateShift(req.params.id, req.body, companyId, actor);
    return res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

// 6. Toggle Shift Status
apiRouter.patch('/attendance/shifts/:id/status', requirePermission(PermissionKey.ATTENDANCE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const { status } = req.body;
    if (status !== 'ACTIVE' && status !== 'INACTIVE') {
      return res.status(400).json({ success: false, error: "Status must be 'ACTIVE' or 'INACTIVE'.", code: 'VALIDATION_ERROR' });
    }
    const actor = getActor(req);
    const updated = await ShiftService.toggleShiftStatus(req.params.id, status, companyId, actor);
    return res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

// 7. Get Shift Assignments List
apiRouter.get('/attendance/shift-assignments', requirePermission(PermissionKey.ATTENDANCE_VIEW), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const { employeeId, shiftId, departmentId, branchId, search, status, effectiveDate } = req.query;
    const filter = {
      employeeId: employeeId ? String(employeeId) : undefined,
      shiftId: shiftId ? String(shiftId) : undefined,
      departmentId: departmentId ? String(departmentId) : undefined,
      branchId: branchId ? String(branchId) : undefined,
      search: search ? String(search) : undefined,
      status: status ? (String(status) as any) : undefined,
      effectiveDate: effectiveDate ? String(effectiveDate) : undefined,
    };
    const assignments = await ShiftService.getEmployeeShiftAssignments(companyId, filter);
    return res.json({ success: true, data: assignments });
  } catch (err) {
    next(err);
  }
});

// 8. Get Single Employee Shift History
apiRouter.get('/attendance/employees/:employeeId/shift-history', requirePermission(PermissionKey.ATTENDANCE_VIEW), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const history = await ShiftService.getEmployeeShiftHistory(req.params.employeeId, companyId);
    return res.json({ success: true, data: history });
  } catch (err) {
    next(err);
  }
});

// 9. Assign Shift to Employee
apiRouter.post('/attendance/shift-assignments', requirePermission(PermissionKey.ATTENDANCE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const created = await ShiftService.assignShift(req.body, companyId, actor);
    return res.status(201).json({ success: true, data: created });
  } catch (err) {
    next(err);
  }
});

// 10. Bulk Shift Assignment
apiRouter.post('/attendance/shift-assignments/bulk', requirePermission(PermissionKey.ATTENDANCE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const actor = getActor(req);
    const result = await ShiftService.bulkAssignShift(req.body, companyId, actor);
    return res.status(201).json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
});

// 11. Get Shift Roster Grid
apiRouter.get('/attendance/shift-roster', requirePermission(PermissionKey.ATTENDANCE_VIEW), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const { startDate, endDate, departmentId, branchId, employeeId, search } = req.query;
    
    // Default to current 7-day week if dates not provided
    const start = startDate ? String(startDate) : new Date().toISOString().slice(0, 10);
    let end = endDate ? String(endDate) : '';
    if (!end) {
      const d = new Date(start);
      d.setDate(d.getDate() + 6);
      end = d.toISOString().slice(0, 10);
    }

    const query = {
      startDate: start,
      endDate: end,
      departmentId: departmentId ? String(departmentId) : undefined,
      branchId: branchId ? String(branchId) : undefined,
      employeeId: employeeId ? String(employeeId) : undefined,
      search: search ? String(search) : undefined,
    };

    const roster = await ShiftService.getShiftRoster(companyId, query);
    return res.json({ success: true, data: roster });
  } catch (err) {
    next(err);
  }
});

// =========================================================================
// PHASE 2B — ATTENDANCE PUNCHES & DAILY/MONTHLY ATTENDANCE ENGINE
// =========================================================================

// Helper to resolve linked employee ID for logged-in user
function resolveEmployeeIdForUser(req: AuthenticatedRequest): string {
  const companyId = req.user?.activeCompanyId || 'comp-101';
  const db = (AttendanceService as any).db;
  const userEmail = req.user?.email;
  const empCode = req.user?.employeeCode;

  const emp = Array.from(db.employees.values()).find(
    (e: any) => e.companyId === companyId && (e.workEmail === userEmail || (empCode && e.employeeCode === empCode))
  );

  if (emp) return (emp as any).id;
  // Fallback to emp-101 for demo admin
  return 'emp-101';
}

// 1. Employee Check-In (ESS)
apiRouter.post('/attendance/check-in', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const employeeId = req.body.employeeId || resolveEmployeeIdForUser(req);
    const actor = req.user!;

    const result = await AttendanceService.recordPunch(
      employeeId,
      companyId,
      {
        punchType: 'CHECK_IN',
        punchTime: req.body.punchTime,
        source: req.body.source || 'ESS',
        deviceId: req.body.deviceId,
        latitude: req.body.latitude,
        longitude: req.body.longitude,
        locationAddress: req.body.locationAddress,
        notes: req.body.notes,
      },
      actor
    );

    return res.status(201).json({
      success: true,
      message: 'Check-in recorded successfully.',
      data: result,
    });
  } catch (err) {
    next(err);
  }
});

// 2. Employee Check-Out (ESS)
apiRouter.post('/attendance/check-out', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const employeeId = req.body.employeeId || resolveEmployeeIdForUser(req);
    const actor = req.user!;

    const result = await AttendanceService.recordPunch(
      employeeId,
      companyId,
      {
        punchType: 'CHECK_OUT',
        punchTime: req.body.punchTime,
        source: req.body.source || 'ESS',
        deviceId: req.body.deviceId,
        latitude: req.body.latitude,
        longitude: req.body.longitude,
        locationAddress: req.body.locationAddress,
        notes: req.body.notes,
      },
      actor
    );

    return res.status(201).json({
      success: true,
      message: 'Check-out recorded successfully.',
      data: result,
    });
  } catch (err) {
    next(err);
  }
});

// 3. My Attendance Today Status (ESS)
apiRouter.get('/attendance/me/status', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const employeeId = resolveEmployeeIdForUser(req);
    const status = await AttendanceService.getEmployeeTodayStatus(employeeId, companyId);
    return res.json({ success: true, data: status });
  } catch (err) {
    next(err);
  }
});

// 4. My Punch & Daily Attendance History (ESS)
apiRouter.get('/attendance/me/history', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const employeeId = resolveEmployeeIdForUser(req);
    const { page, limit, startDate, endDate } = req.query;

    const list = await AttendanceService.getDailyAttendanceList(
      companyId,
      {
        employeeId,
        startDate: startDate ? String(startDate) : undefined,
        endDate: endDate ? String(endDate) : undefined,
        page: page ? parseInt(String(page), 10) : 1,
        limit: limit ? parseInt(String(limit), 10) : 30,
      },
      req.user!
    );

    return res.json({ success: true, data: list });
  } catch (err) {
    next(err);
  }
});

// 5. Daily Attendance List (Company / HR / Manager / Admin)
apiRouter.get('/attendance/daily', requirePermission(PermissionKey.ATTENDANCE_VIEW), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const { date, departmentId, branchId, designationId, employeeId, status, hasException, search } = req.query;

    const result = await AttendanceService.getDailyAttendanceList(
      companyId,
      {
        date: date ? String(date) : undefined,
        departmentId: departmentId ? String(departmentId) : undefined,
        branchId: branchId ? String(branchId) : undefined,
        designationId: designationId ? String(designationId) : undefined,
        employeeId: employeeId ? String(employeeId) : undefined,
        status: status as any,
        hasException: hasException !== undefined ? hasException === 'true' : undefined,
        search: search ? String(search) : undefined,
      },
      req.user!
    );

    return res.json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
});

// 6. Employee Specific Daily Attendance
apiRouter.get('/attendance/employees/:employeeId/daily', requirePermission(PermissionKey.ATTENDANCE_VIEW), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const { employeeId } = req.params;
    const { startDate, endDate } = req.query;

    const result = await AttendanceService.getDailyAttendanceList(
      companyId,
      {
        employeeId,
        startDate: startDate ? String(startDate) : undefined,
        endDate: endDate ? String(endDate) : undefined,
      },
      req.user!
    );

    return res.json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
});

// 7. Monthly Attendance Matrix View
apiRouter.get('/attendance/monthly', requirePermission(PermissionKey.ATTENDANCE_VIEW), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const now = new Date();
    const month = req.query.month ? parseInt(String(req.query.month), 10) : now.getUTCMonth() + 1;
    const year = req.query.year ? parseInt(String(req.query.year), 10) : now.getUTCFullYear();
    const departmentId = req.query.departmentId ? String(req.query.departmentId) : undefined;
    const branchId = req.query.branchId ? String(req.query.branchId) : undefined;
    const employeeId = req.query.employeeId ? String(req.query.employeeId) : undefined;
    const search = req.query.search ? String(req.query.search) : undefined;

    const matrix = await AttendanceService.getMonthlyMatrix(
      companyId,
      { month, year, departmentId, branchId, employeeId, search },
      req.user!
    );

    return res.json({ success: true, data: matrix });
  } catch (err) {
    next(err);
  }
});

// 8. Idempotent / Batch Attendance Recalculation
apiRouter.post('/attendance/recalculate', requirePermission(PermissionKey.ATTENDANCE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const result = await AttendanceService.recalculateAttendance(companyId, req.body, req.user!);
    return res.json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
});

// 9. Regularization Requests Listing
apiRouter.get('/attendance/regularizations', requirePermission(PermissionKey.ATTENDANCE_VIEW), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const { employeeId, status, startDate, endDate } = req.query;

    const requests = await AttendanceService.listRegularizationRequests(
      companyId,
      {
        employeeId: employeeId ? String(employeeId) : undefined,
        status: status as any,
        startDate: startDate ? String(startDate) : undefined,
        endDate: endDate ? String(endDate) : undefined,
      },
      req.user!
    );

    return res.json({ success: true, data: requests });
  } catch (err) {
    next(err);
  }
});

// 10. Submit Regularization Request
apiRouter.post('/attendance/regularizations', requirePermission(PermissionKey.ATTENDANCE_RECORD), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const employeeId = req.body.employeeId || resolveEmployeeIdForUser(req);
    const created = await AttendanceService.submitRegularization(employeeId, companyId, req.body, req.user!);
    return res.status(201).json({ success: true, data: created });
  } catch (err) {
    next(err);
  }
});

// 11. Approve / Reject Regularization Request
apiRouter.patch('/attendance/regularizations/:id/action', requirePermission(PermissionKey.ATTENDANCE_MANAGE), async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const companyId = req.user?.activeCompanyId || 'comp-101';
    const { id } = req.params;
    const actioned = await AttendanceService.actionRegularization(id, companyId, req.body, req.user!);
    return res.json({ success: true, data: actioned });
  } catch (err) {
    next(err);
  }
});

// =========================================================================
// DASHBOARD & ADMINISTRATION
// =========================================================================
apiRouter.get('/dashboard/summary', async (req: AuthenticatedRequest, res: Response) => {
  const companyId = req.user?.activeCompanyId || 'comp-101';
  return res.json({
    success: true,
    data: {
      companyId,
      headcount: companyId === 'comp-102' ? 24 : 56,
      presentToday: companyId === 'comp-102' ? 22 : 48,
      absentToday: companyId === 'comp-102' ? 1 : 3,
      onLeaveToday: companyId === 'comp-102' ? 1 : 5,
      lateArrivalsToday: 2,
      newJoinersThisMonth: companyId === 'comp-102' ? 1 : 4,
      pendingApprovalsCount: companyId === 'comp-102' ? 3 : 7,
      noticePeriodCount: 1,
      asOfDate: new Date().toISOString(),
    },
  });
});

apiRouter.get('/administration/users', requirePermission(PermissionKey.ADMIN_USERS_MANAGE), async (req: AuthenticatedRequest, res: Response) => {
  const users = await AuthService.getUsers();
  return res.json({ success: true, data: users });
});

apiRouter.get('/administration/audit', requirePermission(PermissionKey.ADMIN_AUDIT_VIEW), async (req: AuthenticatedRequest, res: Response) => {
  const isSuperAdmin = req.user?.role === UserRole.SUPER_ADMIN;
  const filterCompany = isSuperAdmin ? undefined : req.user?.activeCompanyId;
  const logs = await AuditService.getLogs(filterCompany);
  return res.json({ success: true, data: logs });
});

// Structured JSON Error Handling Middleware for apiRouter
apiRouter.use((err: any, req: AuthenticatedRequest, res: Response, _next: NextFunction) => {
  console.error('[API Error]:', err);
  const statusCode = typeof err?.statusCode === 'number' ? err.statusCode : 500;
  return res.status(statusCode).json({
    success: false,
    error: err?.message || 'An unexpected internal error occurred.',
    code: err?.code || 'INTERNAL_ERROR',
    statusCode,
  });
});
