import { EmployeeAssignment } from '../../../src/types/employee.js';
import { RelationalDatabase } from '../RelationalDatabase.js';

export class EmployeeAssignmentRepository {
  private static db = RelationalDatabase.getInstance();

  public static async findById(id: string): Promise<EmployeeAssignment | null> {
    return this.db.employeeAssignments.get(id) || null;
  }

  public static async findCurrentAssignment(employeeId: string): Promise<EmployeeAssignment | null> {
    const list = Array.from(this.db.employeeAssignments.values()).filter(
      (a) => a.employeeId === employeeId
    );
    if (list.length === 0) return null;

    // Active assignment has no effectiveTo or latest effectiveFrom
    list.sort((a, b) => new Date(b.effectiveFrom).getTime() - new Date(a.effectiveFrom).getTime());
    const active = list.find((a) => !a.effectiveTo) || list[0];
    return this.enrichAssignment(active);
  }

  public static async findHistory(employeeId: string): Promise<EmployeeAssignment[]> {
    const list = Array.from(this.db.employeeAssignments.values()).filter(
      (a) => a.employeeId === employeeId
    );
    list.sort((a, b) => new Date(b.effectiveFrom).getTime() - new Date(a.effectiveFrom).getTime());
    return list.map((a) => this.enrichAssignment(a));
  }

  public static async create(assignment: EmployeeAssignment): Promise<EmployeeAssignment> {
    this.db.employeeAssignments.set(assignment.id, assignment);
    return this.enrichAssignment(assignment);
  }

  public static async update(id: string, updates: Partial<EmployeeAssignment>): Promise<EmployeeAssignment | null> {
    const existing = this.db.employeeAssignments.get(id);
    if (!existing) return null;

    const updated: EmployeeAssignment = {
      ...existing,
      ...updates,
      id,
      updatedAt: new Date().toISOString(),
    };

    this.db.employeeAssignments.set(id, updated);
    return this.enrichAssignment(updated);
  }

  public static async findDirectReports(managerId: string): Promise<string[]> {
    const activeAssignments = Array.from(this.db.employeeAssignments.values()).filter(
      (a) => a.managerId === managerId && !a.effectiveTo
    );
    return activeAssignments.map((a) => a.employeeId);
  }

  public static async getAllSubordinateIds(managerId: string): Promise<string[]> {
    const result = new Set<string>();
    const queue = [managerId];
    const visited = new Set<string>();

    while (queue.length > 0) {
      const current = queue.shift()!;
      if (visited.has(current)) continue;
      visited.add(current);

      const directs = await this.findDirectReports(current);
      for (const d of directs) {
        if (!result.has(d)) {
          result.add(d);
          queue.push(d);
        }
      }
    }

    return Array.from(result);
  }

  public static async isCircularManager(employeeId: string, proposedManagerId: string): Promise<boolean> {
    if (employeeId === proposedManagerId) return true; // Cannot manage self

    // Check if proposedManager reports to employee (directly or indirectly)
    let currentId: string | undefined = proposedManagerId;
    const visited = new Set<string>();

    while (currentId) {
      if (currentId === employeeId) {
        return true; // Cycle detected: proposed manager is in employee's downstream hierarchy
      }
      if (visited.has(currentId)) {
        break; // Guard against existing loop
      }
      visited.add(currentId);

      const currentAssign = await this.findCurrentAssignment(currentId);
      currentId = currentAssign?.managerId;
    }

    return false;
  }

  private static enrichAssignment(a: EmployeeAssignment): EmployeeAssignment {
    const company = this.db.companies.get(a.companyId);
    const branch = this.db.branches.get(a.branchId);
    const dept = this.db.departments.get(a.departmentId);
    const desig = this.db.designations.get(a.designationId);
    const workLoc = this.db.workLocations.get(a.workLocationId);
    let managerName: string | undefined;
    let managerCode: string | undefined;

    if (a.managerId) {
      const mgr = this.db.employees.get(a.managerId);
      if (mgr) {
        managerName = mgr.displayName;
        managerCode = mgr.employeeCode;
      }
    }

    return {
      ...a,
      companyName: company?.name,
      branchName: branch?.name,
      departmentName: dept?.name,
      designationName: desig?.name,
      workLocationName: workLoc?.name,
      managerName,
      managerCode,
    };
  }
}
