/**
 * PostgreSQL Database & Repository Architecture
 * Phase 1B: Real Organization Master Data Store
 */

import { Company, Branch, Department, Designation, WorkLocation, Holiday } from '../../src/types/organization.js';
import {
  Employee,
  EmployeeAssignment,
  EmployeeAddress,
  EmployeeEmergencyContact,
  EmployeeBankAccount,
  EmployeeStatutoryDetails,
  EmployeeDocument,
  EmployeeStatusHistory,
} from '../../src/types/employee.js';
import {
  Shift,
  ShiftBreak,
  WeeklyOffRule,
  EmployeeShiftAssignment,
  ShiftRosterEntry,
} from '../../src/types/shift.js';
import {
  AttendancePunch,
  DailyAttendance,
  AttendanceRegularizationRequest,
} from '../../src/types/attendance.js';
import {
  OvertimePolicy,
  OvertimeRequest,
} from '../../src/types/overtime.js';
import {
  AttendancePeriod,
  AttendancePeriodSummary,
} from '../../src/types/period.js';

export interface TenantScopedFilter {
  companyId: string;
  status?: 'ACTIVE' | 'INACTIVE';
  search?: string;
  year?: number;
  workLocationId?: string;
  branchId?: string;
}

// In-Memory Relational Master Storage with PostgreSQL Constraints & Multi-Tenant Boundaries
export class RelationalDatabase {
  private static instance: RelationalDatabase;

  // Phase 1B Organization Master
  public companies: Map<string, Company> = new Map();
  public branches: Map<string, Branch> = new Map();
  public departments: Map<string, Department> = new Map();
  public designations: Map<string, Designation> = new Map();
  public workLocations: Map<string, WorkLocation> = new Map();
  public holidays: Map<string, Holiday> = new Map();

  // Phase 1C Employee Core
  public employees: Map<string, Employee> = new Map();
  public employeeAssignments: Map<string, EmployeeAssignment> = new Map();
  public employeeAddresses: Map<string, EmployeeAddress> = new Map();
  public employeeEmergencyContacts: Map<string, EmployeeEmergencyContact> = new Map();
  public employeeBankAccounts: Map<string, EmployeeBankAccount> = new Map();
  public employeeStatutoryDetails: Map<string, EmployeeStatutoryDetails> = new Map();
  public employeeDocuments: Map<string, EmployeeDocument> = new Map();
  public employeeStatusHistory: Map<string, EmployeeStatusHistory> = new Map();

  // Phase 2A Shift Management & Employee Shift Assignments
  public shifts: Map<string, Shift> = new Map();
  public shiftBreaks: Map<string, ShiftBreak> = new Map();
  public weeklyOffRules: Map<string, WeeklyOffRule> = new Map();
  public employeeShiftAssignments: Map<string, EmployeeShiftAssignment> = new Map();
  public shiftRosterEntries: Map<string, ShiftRosterEntry> = new Map();

  // Phase 2B Attendance Punches & Daily Attendance Engine
  public attendancePunches: Map<string, AttendancePunch> = new Map();
  public dailyAttendance: Map<string, DailyAttendance> = new Map();
  public attendanceRegularizationRequests: Map<string, AttendanceRegularizationRequest> = new Map();

  // Phase 2C Overtime, Attendance Finalization & Payroll-Ready Summary
  public overtimePolicies: Map<string, OvertimePolicy> = new Map();
  public overtimeRequests: Map<string, OvertimeRequest> = new Map();
  public attendancePeriods: Map<string, AttendancePeriod> = new Map();
  public attendancePeriodSummaries: Map<string, AttendancePeriodSummary> = new Map();

  private constructor() {
    this.seedInitialMasterData();
  }

  public static getInstance(): RelationalDatabase {
    if (!RelationalDatabase.instance) {
      RelationalDatabase.instance = new RelationalDatabase();
    }
    return RelationalDatabase.instance;
  }

  public seedInitialMasterData(): void {
    // 1. Companies
    const c1: Company = {
      id: 'comp-101',
      code: 'ACME',
      name: 'Acme Enterprise Solutions',
      legalName: 'Acme Enterprise Holdings Inc.',
      status: 'ACTIVE',
      currency: 'USD',
      locale: 'en-US',
      timezone: 'America/New_York',
      taxIdentifier: 'TAX-9982310',
      contactEmail: 'hr@acme-corp.com',
      contactPhone: '+1 (555) 019-2831',
      address: '100 Tech Plaza, Suite 400, New York, NY 10001',
      createdAt: '2026-01-10T08:00:00Z',
      updatedAt: '2026-08-01T10:30:00Z',
      createdBy: 'usr-1',
    };

    const c2: Company = {
      id: 'comp-102',
      code: 'NEXUS',
      name: 'Nexus Tech Global',
      legalName: 'Nexus Global Software Services LLC',
      status: 'ACTIVE',
      currency: 'GBP',
      locale: 'en-GB',
      timezone: 'Europe/London',
      taxIdentifier: 'GB-77123901',
      contactEmail: 'hr@nexusglobal.io',
      contactPhone: '+44 20 7946 0912',
      address: '25 Financial Way, London EC2N 2DB, United Kingdom',
      createdAt: '2026-03-15T09:00:00Z',
      updatedAt: '2026-07-20T14:15:00Z',
      createdBy: 'usr-1',
    };

    this.companies.set(c1.id, c1);
    this.companies.set(c2.id, c2);

    // 2. Branches
    const b1: Branch = {
      id: 'br-1',
      companyId: 'comp-101',
      code: 'NY-HQ',
      name: 'New York Headquarters',
      timezoneOverride: 'America/New_York',
      address: '100 Tech Plaza, Suite 400',
      city: 'New York',
      state: 'NY',
      country: 'USA',
      postalCode: '10001',
      status: 'ACTIVE',
      contactPerson: 'David Miller',
      contactEmail: 'dmiller@acme-corp.com',
      contactPhone: '+1 (555) 019-2831',
      createdAt: '2026-01-10T08:00:00Z',
      updatedAt: '2026-01-10T08:00:00Z',
      createdBy: 'usr-1',
    };

    const b2: Branch = {
      id: 'br-2',
      companyId: 'comp-101',
      code: 'SF-OFFICE',
      name: 'San Francisco Innovation Center',
      timezoneOverride: 'America/Los_Angeles',
      address: '450 Market Street, 12th Floor',
      city: 'San Francisco',
      state: 'CA',
      country: 'USA',
      postalCode: '94105',
      status: 'ACTIVE',
      contactPerson: 'Elena Rostova',
      contactEmail: 'erostova@acme-corp.com',
      contactPhone: '+1 (415) 555-0182',
      createdAt: '2026-02-01T08:00:00Z',
      updatedAt: '2026-02-01T08:00:00Z',
      createdBy: 'usr-1',
    };

    const b3: Branch = {
      id: 'br-3',
      companyId: 'comp-102',
      code: 'LDN-HQ',
      name: 'London Central HQ',
      timezoneOverride: 'Europe/London',
      address: '25 Financial Way',
      city: 'London',
      state: 'Greater London',
      country: 'United Kingdom',
      postalCode: 'EC2N 2DB',
      status: 'ACTIVE',
      contactPerson: 'James Sterling',
      contactEmail: 'jsterling@nexusglobal.io',
      contactPhone: '+44 20 7946 0912',
      createdAt: '2026-03-15T09:00:00Z',
      updatedAt: '2026-03-15T09:00:00Z',
      createdBy: 'usr-1',
    };

    this.branches.set(b1.id, b1);
    this.branches.set(b2.id, b2);
    this.branches.set(b3.id, b3);

    // 3. Departments
    const d1: Department = {
      id: 'dept-1',
      companyId: 'comp-101',
      code: 'ENG',
      name: 'Software Engineering',
      departmentHeadName: 'Robert Vance',
      description: 'Core product engineering, platform infrastructure & quality',
      employeeCount: 42,
      status: 'ACTIVE',
      createdAt: '2026-01-10T08:00:00Z',
      updatedAt: '2026-01-10T08:00:00Z',
      createdBy: 'usr-1',
    };

    const d2: Department = {
      id: 'dept-2',
      companyId: 'comp-101',
      code: 'HR',
      name: 'Human Resources & Talent',
      departmentHeadName: 'Sarah Jenkins',
      description: 'Talent acquisition, employee experience, and people operations',
      employeeCount: 8,
      status: 'ACTIVE',
      createdAt: '2026-01-10T08:00:00Z',
      updatedAt: '2026-01-10T08:00:00Z',
      createdBy: 'usr-1',
    };

    const d3: Department = {
      id: 'dept-3',
      companyId: 'comp-101',
      code: 'FIN',
      name: 'Finance & Payroll',
      departmentHeadName: 'Michael Chang',
      description: 'Financial management, compliance, and corporate payroll',
      employeeCount: 6,
      status: 'ACTIVE',
      createdAt: '2026-01-10T08:00:00Z',
      updatedAt: '2026-01-10T08:00:00Z',
      createdBy: 'usr-1',
    };

    const d4: Department = {
      id: 'dept-4',
      companyId: 'comp-102',
      code: 'NEX-ENG',
      name: 'Cloud Infrastructure Engineering',
      departmentHeadName: 'Alistair Brown',
      description: 'Global cloud solutions & client deployments',
      employeeCount: 20,
      status: 'ACTIVE',
      createdAt: '2026-03-15T09:00:00Z',
      updatedAt: '2026-03-15T09:00:00Z',
      createdBy: 'usr-1',
    };

    this.departments.set(d1.id, d1);
    this.departments.set(d2.id, d2);
    this.departments.set(d3.id, d3);
    this.departments.set(d4.id, d4);

    // 4. Designations
    const des1: Designation = {
      id: 'desig-1',
      companyId: 'comp-101',
      code: 'SWE-SR',
      name: 'Senior Software Engineer',
      gradeLevel: 'L5',
      description: 'Lead engineer for microservices and database architecture',
      employeeCount: 18,
      status: 'ACTIVE',
      createdAt: '2026-01-10T08:00:00Z',
      updatedAt: '2026-01-10T08:00:00Z',
      createdBy: 'usr-1',
    };

    const des2: Designation = {
      id: 'desig-2',
      companyId: 'comp-101',
      code: 'HR-MGR',
      name: 'HR Operations Manager',
      gradeLevel: 'M2',
      description: 'Oversees HR workflow, policies and compliance',
      employeeCount: 3,
      status: 'ACTIVE',
      createdAt: '2026-01-10T08:00:00Z',
      updatedAt: '2026-01-10T08:00:00Z',
      createdBy: 'usr-1',
    };

    const des3: Designation = {
      id: 'desig-3',
      companyId: 'comp-101',
      code: 'PAY-SPEC',
      name: 'Payroll Specialist',
      gradeLevel: 'L4',
      description: 'Responsible for payroll cycles, tax deductions, and statutory filings',
      employeeCount: 2,
      status: 'ACTIVE',
      createdAt: '2026-01-10T08:00:00Z',
      updatedAt: '2026-01-10T08:00:00Z',
      createdBy: 'usr-1',
    };

    const des4: Designation = {
      id: 'desig-4',
      companyId: 'comp-102',
      code: 'CLOUD-ARCH',
      name: 'Principal Cloud Architect',
      gradeLevel: 'L6',
      description: 'Chief technical architect for enterprise systems',
      employeeCount: 4,
      status: 'ACTIVE',
      createdAt: '2026-03-15T09:00:00Z',
      updatedAt: '2026-03-15T09:00:00Z',
      createdBy: 'usr-1',
    };

    this.designations.set(des1.id, des1);
    this.designations.set(des2.id, des2);
    this.designations.set(des3.id, des3);
    this.designations.set(des4.id, des4);

    // 5. Work Locations
    const wl1: WorkLocation = {
      id: 'wl-1',
      companyId: 'comp-101',
      branchId: 'br-1',
      branchName: 'New York Headquarters',
      code: 'NYC-TECH-TOWER',
      name: 'NYC Tech Plaza Tower',
      address: '100 Tech Plaza, Suite 400',
      city: 'New York',
      state: 'NY',
      country: 'USA',
      postalCode: '10001',
      timezone: 'America/New_York',
      status: 'ACTIVE',
      createdAt: '2026-01-10T08:00:00Z',
      updatedAt: '2026-01-10T08:00:00Z',
      createdBy: 'usr-1',
    };

    const wl2: WorkLocation = {
      id: 'wl-2',
      companyId: 'comp-101',
      branchId: 'br-2',
      branchName: 'San Francisco Innovation Center',
      code: 'SFO-INNOV-HUB',
      name: 'San Francisco Innovation Hub',
      address: '450 Market Street, 12th Floor',
      city: 'San Francisco',
      state: 'CA',
      country: 'USA',
      postalCode: '94105',
      timezone: 'America/Los_Angeles',
      status: 'ACTIVE',
      createdAt: '2026-02-01T08:00:00Z',
      updatedAt: '2026-02-01T08:00:00Z',
      createdBy: 'usr-1',
    };

    const wl3: WorkLocation = {
      id: 'wl-3',
      companyId: 'comp-102',
      branchId: 'br-3',
      branchName: 'London Central HQ',
      code: 'LDN-FIN-CTR',
      name: 'London Financial Center',
      address: '25 Financial Way',
      city: 'London',
      state: 'Greater London',
      country: 'United Kingdom',
      postalCode: 'EC2N 2DB',
      timezone: 'Europe/London',
      status: 'ACTIVE',
      createdAt: '2026-03-15T09:00:00Z',
      updatedAt: '2026-03-15T09:00:00Z',
      createdBy: 'usr-1',
    };

    this.workLocations.set(wl1.id, wl1);
    this.workLocations.set(wl2.id, wl2);
    this.workLocations.set(wl3.id, wl3);

    // 6. Holidays
    const h1: Holiday = {
      id: 'hol-1',
      companyId: 'comp-101',
      name: "New Year's Day",
      date: '2026-01-01',
      type: 'PUBLIC',
      description: 'Official Public Holiday',
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
      createdBy: 'usr-1',
    };

    const h2: Holiday = {
      id: 'hol-2',
      companyId: 'comp-101',
      name: 'Memorial Day',
      date: '2026-05-25',
      type: 'PUBLIC',
      description: 'Federal Memorial Day',
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
      createdBy: 'usr-1',
    };

    const h3: Holiday = {
      id: 'hol-3',
      companyId: 'comp-101',
      name: 'Independence Day',
      date: '2026-07-04',
      type: 'PUBLIC',
      description: 'US Independence Day',
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
      createdBy: 'usr-1',
    };

    const h4: Holiday = {
      id: 'hol-4',
      companyId: 'comp-101',
      name: 'Annual Foundation Day',
      date: '2026-10-15',
      type: 'COMPANY',
      description: 'Acme Enterprise Global Celebration',
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
      createdBy: 'usr-1',
    };

    const h5: Holiday = {
      id: 'hol-5',
      companyId: 'comp-102',
      name: 'Early May Bank Holiday',
      date: '2026-05-04',
      type: 'PUBLIC',
      description: 'UK Statutory Bank Holiday',
      status: 'ACTIVE',
      createdAt: '2026-03-15T09:00:00Z',
      updatedAt: '2026-03-15T09:00:00Z',
      createdBy: 'usr-1',
    };

    this.holidays.set(h1.id, h1);
    this.holidays.set(h2.id, h2);
    this.holidays.set(h3.id, h3);
    this.holidays.set(h4.id, h4);
    this.holidays.set(h5.id, h5);

    // Initial Employee Seed: Alexander Vance (comp-101)
    const emp1: Employee = {
      id: 'emp-101',
      companyId: 'comp-101',
      employeeCode: 'EMP-001',
      firstName: 'Alexander',
      lastName: 'Vance',
      displayName: 'Alexander Vance',
      gender: 'MALE',
      dateOfBirth: '1985-06-15',
      maritalStatus: 'MARRIED',
      nationality: 'American',
      personalEmail: 'alex.vance@personal.com',
      workEmail: 'admin@hrms.enterprise.com',
      mobileNumber: '+1 555-0101',
      joiningDate: '2022-01-10',
      probationPeriodMonths: 0,
      noticePeriodDays: 60,
      employmentType: 'FULL_TIME',
      status: 'ACTIVE',
      createdAt: '2022-01-10T09:00:00Z',
      updatedAt: '2022-01-10T09:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };
    this.employees.set(emp1.id, emp1);

    const asg1: EmployeeAssignment = {
      id: 'asg-101',
      employeeId: emp1.id,
      companyId: 'comp-101',
      branchId: 'br-1',
      departmentId: 'dept-1',
      designationId: 'desig-1',
      workLocationId: 'loc-1',
      effectiveFrom: '2022-01-10',
      changeReason: 'INITIAL_JOINING',
      notes: 'Executive leadership assignment.',
      createdAt: '2022-01-10T09:00:00Z',
      updatedAt: '2022-01-10T09:00:00Z',
      createdBy: 'usr-1',
    };
    this.employeeAssignments.set(asg1.id, asg1);

    // Initial Employee Seed: Sarah Jenkins (comp-101)
    const emp2: Employee = {
      id: 'emp-102',
      companyId: 'comp-101',
      employeeCode: 'EMP-002',
      firstName: 'Sarah',
      lastName: 'Jenkins',
      displayName: 'Sarah Jenkins',
      gender: 'FEMALE',
      dateOfBirth: '1990-03-22',
      maritalStatus: 'MARRIED',
      nationality: 'American',
      personalEmail: 'sarah.j@gmail.com',
      workEmail: 'hr.admin@acme-corp.com',
      mobileNumber: '+1 555-0102',
      joiningDate: '2022-03-01',
      probationPeriodMonths: 3,
      noticePeriodDays: 30,
      employmentType: 'FULL_TIME',
      status: 'ACTIVE',
      createdAt: '2022-03-01T09:00:00Z',
      updatedAt: '2022-03-01T09:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };
    this.employees.set(emp2.id, emp2);

    const asg2: EmployeeAssignment = {
      id: 'asg-102',
      employeeId: emp2.id,
      companyId: 'comp-101',
      branchId: 'br-1',
      departmentId: 'dept-2',
      designationId: 'desig-2',
      workLocationId: 'loc-1',
      managerId: emp1.id,
      effectiveFrom: '2022-03-01',
      changeReason: 'INITIAL_JOINING',
      notes: 'HR Director appointment.',
      createdAt: '2022-03-01T09:00:00Z',
      updatedAt: '2022-03-01T09:00:00Z',
      createdBy: 'usr-1',
    };
    this.employeeAssignments.set(asg2.id, asg2);

    // Initial Employee Seed: Robert Vance (comp-101)
    const emp3: Employee = {
      id: 'emp-103',
      companyId: 'comp-101',
      employeeCode: 'EMP-003',
      firstName: 'Robert',
      lastName: 'Vance',
      displayName: 'Robert Vance',
      gender: 'MALE',
      dateOfBirth: '1988-11-05',
      maritalStatus: 'SINGLE',
      nationality: 'American',
      personalEmail: 'robert.v@gmail.com',
      workEmail: 'manager@acme-corp.com',
      mobileNumber: '+1 555-0103',
      joiningDate: '2022-05-15',
      probationPeriodMonths: 3,
      noticePeriodDays: 30,
      employmentType: 'FULL_TIME',
      status: 'ACTIVE',
      createdAt: '2022-05-15T09:00:00Z',
      updatedAt: '2022-05-15T09:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };
    this.employees.set(emp3.id, emp3);

    const asg3: EmployeeAssignment = {
      id: 'asg-103',
      employeeId: emp3.id,
      companyId: 'comp-101',
      branchId: 'br-1',
      departmentId: 'dept-1',
      designationId: 'desig-3',
      workLocationId: 'loc-1',
      managerId: emp1.id,
      effectiveFrom: '2022-05-15',
      changeReason: 'INITIAL_JOINING',
      notes: 'Engineering management assignment.',
      createdAt: '2022-05-15T09:00:00Z',
      updatedAt: '2022-05-15T09:00:00Z',
      createdBy: 'usr-1',
    };
    this.employeeAssignments.set(asg3.id, asg3);

    // Initial Employee Seed: John Doe (comp-101)
    const emp4: Employee = {
      id: 'emp-104',
      companyId: 'comp-101',
      employeeCode: 'EMP-010',
      firstName: 'John',
      lastName: 'Doe',
      displayName: 'John Doe',
      gender: 'MALE',
      dateOfBirth: '1995-08-20',
      maritalStatus: 'SINGLE',
      nationality: 'American',
      personalEmail: 'johndoe.personal@gmail.com',
      workEmail: 'john.doe@acme-corp.com',
      mobileNumber: '+1 555-0110',
      joiningDate: '2023-02-01',
      probationPeriodMonths: 3,
      noticePeriodDays: 30,
      employmentType: 'FULL_TIME',
      status: 'ACTIVE',
      createdAt: '2023-02-01T09:00:00Z',
      updatedAt: '2023-02-01T09:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };
    this.employees.set(emp4.id, emp4);

    const asg4: EmployeeAssignment = {
      id: 'asg-104',
      employeeId: emp4.id,
      companyId: 'comp-101',
      branchId: 'br-1',
      departmentId: 'dept-1',
      designationId: 'desig-3',
      workLocationId: 'loc-1',
      managerId: emp3.id,
      effectiveFrom: '2023-02-01',
      changeReason: 'INITIAL_JOINING',
      notes: 'Software engineer placement.',
      createdAt: '2023-02-01T09:00:00Z',
      updatedAt: '2023-02-01T09:00:00Z',
      createdBy: 'usr-1',
    };
    this.employeeAssignments.set(asg4.id, asg4);

    // Initial Employee Seed for comp-102: Emily Clark (comp-102 isolation test record)
    const emp5: Employee = {
      id: 'emp-201',
      companyId: 'comp-102',
      employeeCode: 'NEX-001',
      firstName: 'Emily',
      lastName: 'Clark',
      displayName: 'Emily Clark',
      gender: 'FEMALE',
      dateOfBirth: '1992-04-12',
      maritalStatus: 'SINGLE',
      nationality: 'British',
      personalEmail: 'emily.clark@nexus.uk',
      workEmail: 'emily.clark@nexus-tech.co.uk',
      mobileNumber: '+44 20 7946 0991',
      joiningDate: '2023-06-01',
      probationPeriodMonths: 3,
      noticePeriodDays: 60,
      employmentType: 'FULL_TIME',
      status: 'ACTIVE',
      createdAt: '2023-06-01T09:00:00Z',
      updatedAt: '2023-06-01T09:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };
    this.employees.set(emp5.id, emp5);

    const asg5: EmployeeAssignment = {
      id: 'asg-201',
      employeeId: emp5.id,
      companyId: 'comp-102',
      branchId: 'br-3',
      departmentId: 'dept-4',
      designationId: 'desig-5',
      workLocationId: 'loc-3',
      effectiveFrom: '2023-06-01',
      changeReason: 'INITIAL_JOINING',
      notes: 'UK Tech lead assignment.',
      createdAt: '2023-06-01T09:00:00Z',
      updatedAt: '2023-06-01T09:00:00Z',
      createdBy: 'usr-1',
    };
    this.employeeAssignments.set(asg5.id, asg5);

    // =========================================================================
    // PHASE 2A: SHIFTS, BREAKS, WEEKLY OFFS, AND ASSIGNMENTS SEEDING
    // =========================================================================

    // Shift 1: GENERAL (comp-101)
    const s1: Shift = {
      id: 'shift-101',
      companyId: 'comp-101',
      code: 'GENERAL',
      name: 'General Day Shift',
      description: 'Core standard business hours (09:30 to 18:30)',
      startTime: '09:30',
      endTime: '18:30',
      isOvernight: false,
      lateEntryGraceMinutes: 15,
      earlyExitGraceMinutes: 15,
      lateAllowed: true,
      earlyExitAllowed: true,
      halfDayHours: 4.5,
      fullDayHours: 8.0,
      color: '#3B82F6',
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };
    this.shifts.set(s1.id, s1);

    const sb1: ShiftBreak = {
      id: 'brk-101-1',
      shiftId: 'shift-101',
      companyId: 'comp-101',
      breakName: 'Lunch Break',
      startTime: '13:00',
      endTime: '14:00',
      durationMinutes: 60,
      isPaid: false,
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    };
    this.shiftBreaks.set(sb1.id, sb1);

    const wo1: WeeklyOffRule = {
      id: 'wo-101-1',
      companyId: 'comp-101',
      shiftId: 'shift-101',
      name: 'Sunday + Alt Saturday Off',
      daysOfWeek: ['SUNDAY'],
      alternateSaturday: true,
      isDefault: true,
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    };
    this.weeklyOffRules.set(wo1.id, wo1);

    // Shift 2: MORNING (comp-101)
    const s2: Shift = {
      id: 'shift-102',
      companyId: 'comp-101',
      code: 'MORNING',
      name: 'Morning Shift',
      description: 'Early operations & facility logistics (06:00 to 15:00)',
      startTime: '06:00',
      endTime: '15:00',
      isOvernight: false,
      lateEntryGraceMinutes: 15,
      earlyExitGraceMinutes: 15,
      lateAllowed: true,
      earlyExitAllowed: true,
      halfDayHours: 4.5,
      fullDayHours: 8.0,
      color: '#10B981',
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };
    this.shifts.set(s2.id, s2);

    const b2_1: ShiftBreak = {
      id: 'brk-102-1',
      shiftId: 'shift-102',
      companyId: 'comp-101',
      breakName: 'Breakfast Break',
      startTime: '09:00',
      endTime: '09:30',
      durationMinutes: 30,
      isPaid: true,
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    };
    const b2_2: ShiftBreak = {
      id: 'brk-102-2',
      shiftId: 'shift-102',
      companyId: 'comp-101',
      breakName: 'Lunch Break',
      startTime: '12:30',
      endTime: '13:00',
      durationMinutes: 30,
      isPaid: false,
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    };
    this.shiftBreaks.set(b2_1.id, b2_1);
    this.shiftBreaks.set(b2_2.id, b2_2);

    const wo2: WeeklyOffRule = {
      id: 'wo-101-2',
      companyId: 'comp-101',
      shiftId: 'shift-102',
      name: 'Sunday Weekly Off',
      daysOfWeek: ['SUNDAY'],
      alternateSaturday: false,
      isDefault: false,
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    };
    this.weeklyOffRules.set(wo2.id, wo2);

    // Shift 3: NIGHT (comp-101) - Overnight Shift 21:00 -> 06:00
    const s3: Shift = {
      id: 'shift-103',
      companyId: 'comp-101',
      code: 'NIGHT',
      name: 'Night Shift (Overnight)',
      description: 'Overnight technical support & server infrastructure (21:00 to 06:00)',
      startTime: '21:00',
      endTime: '06:00',
      isOvernight: true,
      lateEntryGraceMinutes: 15,
      earlyExitGraceMinutes: 15,
      lateAllowed: true,
      earlyExitAllowed: true,
      halfDayHours: 4.5,
      fullDayHours: 8.0,
      color: '#6366F1',
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };
    this.shifts.set(s3.id, s3);

    const sb3: ShiftBreak = {
      id: 'brk-103-1',
      shiftId: 'shift-103',
      companyId: 'comp-101',
      breakName: 'Midnight Meal Break',
      startTime: '01:00',
      endTime: '01:45',
      durationMinutes: 45,
      isPaid: false,
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    };
    this.shiftBreaks.set(sb3.id, sb3);

    const wo3: WeeklyOffRule = {
      id: 'wo-101-3',
      companyId: 'comp-101',
      shiftId: 'shift-103',
      name: 'Sunday Weekly Off',
      daysOfWeek: ['SUNDAY'],
      alternateSaturday: false,
      isDefault: false,
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    };
    this.weeklyOffRules.set(wo3.id, wo3);

    // Shift 4: UK_GENERAL (comp-102)
    const s4: Shift = {
      id: 'shift-201',
      companyId: 'comp-102',
      code: 'UK_GENERAL',
      name: 'UK Core Standard',
      description: 'UK standard business operations (09:00 to 17:30)',
      startTime: '09:00',
      endTime: '17:30',
      isOvernight: false,
      lateEntryGraceMinutes: 10,
      earlyExitGraceMinutes: 10,
      lateAllowed: true,
      earlyExitAllowed: true,
      halfDayHours: 4.0,
      fullDayHours: 7.5,
      color: '#0EA5E9',
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };
    this.shifts.set(s4.id, s4);

    const sb4: ShiftBreak = {
      id: 'brk-201-1',
      shiftId: 'shift-201',
      companyId: 'comp-102',
      breakName: 'Lunch Break',
      startTime: '12:30',
      endTime: '13:30',
      durationMinutes: 60,
      isPaid: false,
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    };
    this.shiftBreaks.set(sb4.id, sb4);

    const wo4: WeeklyOffRule = {
      id: 'wo-201-1',
      companyId: 'comp-102',
      shiftId: 'shift-201',
      name: 'UK Weekend Off (Sat + Sun)',
      daysOfWeek: ['SATURDAY', 'SUNDAY'],
      alternateSaturday: false,
      isDefault: true,
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    };
    this.weeklyOffRules.set(wo4.id, wo4);

    // Initial Employee Shift Assignments
    const esa1: EmployeeShiftAssignment = {
      id: 'esa-101',
      employeeId: 'emp-101',
      companyId: 'comp-101',
      shiftId: 'shift-101',
      effectiveFrom: '2026-01-10',
      assignmentType: 'PERMANENT',
      reason: 'Initial onboarding assignment to General Shift.',
      status: 'ACTIVE',
      createdAt: '2026-01-10T08:00:00Z',
      updatedAt: '2026-01-10T08:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };
    const esa2: EmployeeShiftAssignment = {
      id: 'esa-102',
      employeeId: 'emp-102',
      companyId: 'comp-101',
      shiftId: 'shift-101',
      effectiveFrom: '2026-01-15',
      assignmentType: 'PERMANENT',
      reason: 'Initial onboarding assignment to General Shift.',
      status: 'ACTIVE',
      createdAt: '2026-01-15T08:00:00Z',
      updatedAt: '2026-01-15T08:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };
    const esa3: EmployeeShiftAssignment = {
      id: 'esa-103',
      employeeId: 'emp-103',
      companyId: 'comp-101',
      shiftId: 'shift-102',
      effectiveFrom: '2026-02-01',
      assignmentType: 'PERMANENT',
      reason: 'Operations morning shift schedule.',
      status: 'ACTIVE',
      createdAt: '2026-02-01T08:00:00Z',
      updatedAt: '2026-02-01T08:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };
    const esa4: EmployeeShiftAssignment = {
      id: 'esa-104',
      employeeId: 'emp-104',
      companyId: 'comp-101',
      shiftId: 'shift-101',
      effectiveFrom: '2026-02-15',
      assignmentType: 'PERMANENT',
      reason: 'Design lead standard schedule.',
      status: 'ACTIVE',
      createdAt: '2026-02-15T08:00:00Z',
      updatedAt: '2026-02-15T08:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };
    const esa5: EmployeeShiftAssignment = {
      id: 'esa-201',
      employeeId: 'emp-201',
      companyId: 'comp-102',
      shiftId: 'shift-201',
      effectiveFrom: '2023-06-01',
      assignmentType: 'PERMANENT',
      reason: 'UK Tech lead standard shift.',
      status: 'ACTIVE',
      createdAt: '2023-06-01T09:00:00Z',
      updatedAt: '2023-06-01T09:00:00Z',
      createdBy: 'usr-1',
      updatedBy: 'usr-1',
    };

    this.employeeShiftAssignments.set(esa1.id, esa1);
    this.employeeShiftAssignments.set(esa2.id, esa2);
    this.employeeShiftAssignments.set(esa3.id, esa3);
    this.employeeShiftAssignments.set(esa4.id, esa4);
    this.employeeShiftAssignments.set(esa5.id, esa5);

    // 8. Phase 2B Attendance Seed Data
    this.seedInitialAttendanceData();
  }

  public seedInitialAttendanceData(): void {
    // Seed sample raw punches and daily attendance for past working days in August 2026
    // August 2026: 
    // 2026-08-01: Saturday (1st Saturday - working)
    // 2026-08-02: Sunday (Weekly Off)
    // 2026-08-03 to 2026-08-07: Mon-Fri (Working)
    // 2026-08-08: Saturday (2nd Saturday - Weekly Off)
    // 2026-08-09: Sunday (Weekly Off)
    // 2026-08-10 to 2026-08-14: Mon-Fri (Working)
    // 2026-08-15: Saturday (Independence Day - HOLIDAY)

    const empList = ['emp-101', 'emp-102', 'emp-103', 'emp-104'];

    // Seed for 2026-08-10 (Monday - Present / Normal)
    const p1: AttendancePunch = {
      id: 'pnch-101-1',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      punchTime: '2026-08-10T09:28:00Z',
      punchType: 'CHECK_IN',
      source: 'WEB',
      createdAt: '2026-08-10T09:28:00Z',
      createdBy: 'usr-1',
    };
    const p2: AttendancePunch = {
      id: 'pnch-101-2',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      punchTime: '2026-08-10T18:35:00Z',
      punchType: 'CHECK_OUT',
      source: 'WEB',
      createdAt: '2026-08-10T18:35:00Z',
      createdBy: 'usr-1',
    };
    this.attendancePunches.set(p1.id, p1);
    this.attendancePunches.set(p2.id, p2);

    const da1: DailyAttendance = {
      id: 'da-101-20260810',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      attendanceDate: '2026-08-10',
      shiftId: 'shift-101',
      shiftCode: 'GEN',
      shiftName: 'General Day Shift',
      scheduledStart: '09:30',
      scheduledEnd: '18:30',
      isOvernight: false,
      firstCheckIn: '2026-08-10T09:28:00Z',
      lastCheckOut: '2026-08-10T18:35:00Z',
      grossWorkMinutes: 547,
      breakMinutes: 60,
      netWorkMinutes: 487, // > 480 mins (8 hours) -> PRESENT
      lateMinutes: 0,
      earlyExitMinutes: 0,
      status: 'PRESENT',
      calculationStatus: 'CALCULATED',
      isLate: false,
      isEarlyExit: false,
      isHalfDay: false,
      isHoliday: false,
      isWeeklyOff: false,
      isOnLeave: false,
      hasException: false,
      calculationVersion: 1,
      calculatedAt: '2026-08-10T18:35:00Z',
      updatedAt: '2026-08-10T18:35:00Z',
    };
    this.dailyAttendance.set(da1.id, da1);

    // 2026-08-11 (Tuesday - Late Arrival by 25 mins)
    const p3: AttendancePunch = {
      id: 'pnch-101-3',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      punchTime: '2026-08-11T09:55:00Z', // 25 mins past 09:30, grace is 15 -> late 25 mins
      punchType: 'CHECK_IN',
      source: 'MOBILE',
      createdAt: '2026-08-11T09:55:00Z',
      createdBy: 'usr-1',
    };
    const p4: AttendancePunch = {
      id: 'pnch-101-4',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      punchTime: '2026-08-11T18:40:00Z',
      punchType: 'CHECK_OUT',
      source: 'MOBILE',
      createdAt: '2026-08-11T18:40:00Z',
      createdBy: 'usr-1',
    };
    this.attendancePunches.set(p3.id, p3);
    this.attendancePunches.set(p4.id, p4);

    const da2: DailyAttendance = {
      id: 'da-101-20260811',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      attendanceDate: '2026-08-11',
      shiftId: 'shift-101',
      shiftCode: 'GEN',
      shiftName: 'General Day Shift',
      scheduledStart: '09:30',
      scheduledEnd: '18:30',
      isOvernight: false,
      firstCheckIn: '2026-08-11T09:55:00Z',
      lastCheckOut: '2026-08-11T18:40:00Z',
      grossWorkMinutes: 525,
      breakMinutes: 60,
      netWorkMinutes: 465,
      lateMinutes: 25,
      earlyExitMinutes: 0,
      status: 'PRESENT',
      calculationStatus: 'CALCULATED',
      isLate: true,
      isEarlyExit: false,
      isHalfDay: false,
      isHoliday: false,
      isWeeklyOff: false,
      isOnLeave: false,
      hasException: true,
      exceptionType: 'LATE_ARRIVAL',
      calculationVersion: 1,
      calculatedAt: '2026-08-11T18:40:00Z',
      updatedAt: '2026-08-11T18:40:00Z',
    };
    this.dailyAttendance.set(da2.id, da2);

    // 2026-08-12 (Wednesday - Missing Check-out punch / Incomplete)
    const p5: AttendancePunch = {
      id: 'pnch-101-5',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      punchTime: '2026-08-12T09:30:00Z',
      punchType: 'CHECK_IN',
      source: 'WEB',
      createdAt: '2026-08-12T09:30:00Z',
      createdBy: 'usr-1',
    };
    this.attendancePunches.set(p5.id, p5);

    const da3: DailyAttendance = {
      id: 'da-101-20260812',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      attendanceDate: '2026-08-12',
      shiftId: 'shift-101',
      shiftCode: 'GEN',
      shiftName: 'General Day Shift',
      scheduledStart: '09:30',
      scheduledEnd: '18:30',
      isOvernight: false,
      firstCheckIn: '2026-08-12T09:30:00Z',
      grossWorkMinutes: 0,
      breakMinutes: 0,
      netWorkMinutes: 0,
      lateMinutes: 0,
      earlyExitMinutes: 0,
      status: 'INCOMPLETE',
      calculationStatus: 'CALCULATED',
      isLate: false,
      isEarlyExit: false,
      isHalfDay: false,
      isHoliday: false,
      isWeeklyOff: false,
      isOnLeave: false,
      hasException: true,
      exceptionType: 'MISSING_OUT',
      calculationVersion: 1,
      calculatedAt: '2026-08-12T18:30:00Z',
      updatedAt: '2026-08-12T18:30:00Z',
    };
    this.dailyAttendance.set(da3.id, da3);

    // Regularization request for 2026-08-12 missing checkout
    const reg1: AttendanceRegularizationRequest = {
      id: 'reg-101-1',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      attendanceDate: '2026-08-12',
      requestedCheckIn: '2026-08-12T09:30:00Z',
      requestedCheckOut: '2026-08-12T18:30:00Z',
      reason: 'Biometric/Web punch missed due to client deployment.',
      reasonDetails: 'Worked continuously at client data center until 18:30.',
      status: 'PENDING',
      createdAt: '2026-08-13T09:00:00Z',
      updatedAt: '2026-08-13T09:00:00Z',
      createdBy: 'usr-1',
    };
    this.attendanceRegularizationRequests.set(reg1.id, reg1);

    // 2026-08-13 (Thursday - Half Day - checked out early at 14:00)
    const p6: AttendancePunch = {
      id: 'pnch-101-6',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      punchTime: '2026-08-13T09:30:00Z',
      punchType: 'CHECK_IN',
      source: 'WEB',
      createdAt: '2026-08-13T09:30:00Z',
      createdBy: 'usr-1',
    };
    const p7: AttendancePunch = {
      id: 'pnch-101-7',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      punchTime: '2026-08-13T14:30:00Z',
      punchType: 'CHECK_OUT',
      source: 'WEB',
      createdAt: '2026-08-13T14:30:00Z',
      createdBy: 'usr-1',
    };
    this.attendancePunches.set(p6.id, p6);
    this.attendancePunches.set(p7.id, p7);

    const da4: DailyAttendance = {
      id: 'da-101-20260813',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      attendanceDate: '2026-08-13',
      shiftId: 'shift-101',
      shiftCode: 'GEN',
      shiftName: 'General Day Shift',
      scheduledStart: '09:30',
      scheduledEnd: '18:30',
      isOvernight: false,
      firstCheckIn: '2026-08-13T09:30:00Z',
      lastCheckOut: '2026-08-13T14:30:00Z',
      grossWorkMinutes: 300,
      breakMinutes: 0,
      netWorkMinutes: 300, // 5 hours (>= 4.5 hrs halfDayHours, < 8 hrs fullDayHours)
      lateMinutes: 0,
      earlyExitMinutes: 240,
      status: 'HALF_DAY',
      calculationStatus: 'CALCULATED',
      isLate: false,
      isEarlyExit: true,
      isHalfDay: true,
      isHoliday: false,
      isWeeklyOff: false,
      isOnLeave: false,
      hasException: true,
      exceptionType: 'EARLY_EXIT',
      calculationVersion: 1,
      calculatedAt: '2026-08-13T14:30:00Z',
      updatedAt: '2026-08-13T14:30:00Z',
    };
    this.dailyAttendance.set(da4.id, da4);

    // 2026-08-14 (Friday - Today - Checked in at 09:25)
    const p8: AttendancePunch = {
      id: 'pnch-101-8',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      punchTime: '2026-08-14T09:25:00Z',
      punchType: 'CHECK_IN',
      source: 'ESS',
      createdAt: '2026-08-14T09:25:00Z',
      createdBy: 'usr-1',
    };
    this.attendancePunches.set(p8.id, p8);

    const da5: DailyAttendance = {
      id: 'da-101-20260814',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      attendanceDate: '2026-08-14',
      shiftId: 'shift-101',
      shiftCode: 'GEN',
      shiftName: 'General Day Shift',
      scheduledStart: '09:30',
      scheduledEnd: '18:30',
      isOvernight: false,
      firstCheckIn: '2026-08-14T09:25:00Z',
      grossWorkMinutes: 0,
      breakMinutes: 0,
      netWorkMinutes: 0,
      lateMinutes: 0,
      earlyExitMinutes: 0,
      status: 'PRESENT',
      calculationStatus: 'CALCULATED',
      isLate: false,
      isEarlyExit: false,
      isHalfDay: false,
      isHoliday: false,
      isWeeklyOff: false,
      isOnLeave: false,
      hasException: false,
      calculationVersion: 1,
      calculatedAt: '2026-08-14T09:25:00Z',
      updatedAt: '2026-08-14T09:25:00Z',
    };
    this.dailyAttendance.set(da5.id, da5);

    // Seed other employees for 2026-08-14 (Today)
    // EMP-102 (Sarah Jenkins)
    const p102_1: AttendancePunch = {
      id: 'pnch-102-1',
      companyId: 'comp-101',
      employeeId: 'emp-102',
      punchTime: '2026-08-14T09:20:00Z',
      punchType: 'CHECK_IN',
      source: 'WEB',
      createdAt: '2026-08-14T09:20:00Z',
    };
    this.attendancePunches.set(p102_1.id, p102_1);
    this.dailyAttendance.set('da-102-20260814', {
      id: 'da-102-20260814',
      companyId: 'comp-101',
      employeeId: 'emp-102',
      attendanceDate: '2026-08-14',
      shiftId: 'shift-101',
      shiftCode: 'GEN',
      shiftName: 'General Day Shift',
      scheduledStart: '09:30',
      scheduledEnd: '18:30',
      isOvernight: false,
      firstCheckIn: '2026-08-14T09:20:00Z',
      grossWorkMinutes: 0,
      breakMinutes: 0,
      netWorkMinutes: 0,
      lateMinutes: 0,
      earlyExitMinutes: 0,
      status: 'PRESENT',
      calculationStatus: 'CALCULATED',
      isLate: false,
      isEarlyExit: false,
      isHalfDay: false,
      isHoliday: false,
      isWeeklyOff: false,
      isOnLeave: false,
      hasException: false,
      calculationVersion: 1,
      calculatedAt: '2026-08-14T09:20:00Z',
      updatedAt: '2026-08-14T09:20:00Z',
    });

    // EMP-103 (Robert Vance - Morning Shift 06:00 to 14:30)
    const p103_1: AttendancePunch = {
      id: 'pnch-103-1',
      companyId: 'comp-101',
      employeeId: 'emp-103',
      punchTime: '2026-08-14T06:02:00Z',
      punchType: 'CHECK_IN',
      source: 'BIOMETRIC',
      createdAt: '2026-08-14T06:02:00Z',
    };
    const p103_2: AttendancePunch = {
      id: 'pnch-103-2',
      companyId: 'comp-101',
      employeeId: 'emp-103',
      punchTime: '2026-08-14T14:35:00Z',
      punchType: 'CHECK_OUT',
      source: 'BIOMETRIC',
      createdAt: '2026-08-14T14:35:00Z',
    };
    this.attendancePunches.set(p103_1.id, p103_1);
    this.attendancePunches.set(p103_2.id, p103_2);
    this.dailyAttendance.set('da-103-20260814', {
      id: 'da-103-20260814',
      companyId: 'comp-101',
      employeeId: 'emp-103',
      attendanceDate: '2026-08-14',
      shiftId: 'shift-102',
      shiftCode: 'MOR',
      shiftName: 'Morning Shift',
      scheduledStart: '06:00',
      scheduledEnd: '14:30',
      isOvernight: false,
      firstCheckIn: '2026-08-14T06:02:00Z',
      lastCheckOut: '2026-08-14T14:35:00Z',
      grossWorkMinutes: 513,
      breakMinutes: 30, // Unpaid lunch
      netWorkMinutes: 483,
      lateMinutes: 0,
      earlyExitMinutes: 0,
      status: 'PRESENT',
      calculationStatus: 'CALCULATED',
      isLate: false,
      isEarlyExit: false,
      isHalfDay: false,
      isHoliday: false,
      isWeeklyOff: false,
      isOnLeave: false,
      hasException: false,
      calculationVersion: 1,
      calculatedAt: '2026-08-14T14:35:00Z',
      updatedAt: '2026-08-14T14:35:00Z',
    });

    // EMP-104 (Elena Rostova - Absent today / not checked in)
    this.dailyAttendance.set('da-104-20260814', {
      id: 'da-104-20260814',
      companyId: 'comp-101',
      employeeId: 'emp-104',
      attendanceDate: '2026-08-14',
      shiftId: 'shift-101',
      shiftCode: 'GEN',
      shiftName: 'General Day Shift',
      scheduledStart: '09:30',
      scheduledEnd: '18:30',
      isOvernight: false,
      grossWorkMinutes: 0,
      breakMinutes: 0,
      netWorkMinutes: 0,
      lateMinutes: 0,
      earlyExitMinutes: 0,
      status: 'ABSENT',
      calculationStatus: 'CALCULATED',
      isLate: false,
      isEarlyExit: false,
      isHalfDay: false,
      isHoliday: false,
      isWeeklyOff: false,
      isOnLeave: false,
      hasException: true,
      exceptionType: 'MISSING_IN',
      calculationVersion: 1,
      calculatedAt: '2026-08-14T09:30:00Z',
      updatedAt: '2026-08-14T09:30:00Z',
    });

    // 14. Phase 2C Overtime Policies
    const otPolicy1: OvertimePolicy = {
      id: 'otp-101',
      companyId: 'comp-101',
      code: 'STD_OT_POLICY',
      name: 'Standard Overtime Policy',
      minQualifyingMinutes: 30,
      roundingIntervalMinutes: 15,
      maxDailyOtMinutes: 240,
      maxMonthlyOtMinutes: 3600,
      preApprovalRequired: false,
      postApprovalAllowed: true,
      weeklyOffEligible: true,
      holidayEligible: true,
      status: 'ACTIVE',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-08-01T00:00:00Z',
      createdBy: 'usr-1',
    };

    const otPolicy2: OvertimePolicy = {
      id: 'otp-102',
      companyId: 'comp-102',
      code: 'NEXUS_OT_POLICY',
      name: 'Nexus Standard Overtime Policy',
      minQualifyingMinutes: 30,
      roundingIntervalMinutes: 15,
      maxDailyOtMinutes: 180,
      maxMonthlyOtMinutes: 2400,
      preApprovalRequired: false,
      postApprovalAllowed: true,
      weeklyOffEligible: true,
      holidayEligible: true,
      status: 'ACTIVE',
      createdAt: '2026-03-01T00:00:00Z',
      updatedAt: '2026-08-01T00:00:00Z',
      createdBy: 'usr-1',
    };

    this.overtimePolicies.set(otPolicy1.id, otPolicy1);
    this.overtimePolicies.set(otPolicy2.id, otPolicy2);

    // 15. Phase 2C Attendance Periods
    // Acme Comp-101: August 2026 (Open / Under Review)
    const periodAugComp1: AttendancePeriod = {
      id: 'period-comp101-202608',
      companyId: 'comp-101',
      code: 'AUG-2026',
      name: 'August 2026 Attendance Period',
      year: 2026,
      month: 8,
      startDate: '2026-08-01',
      endDate: '2026-08-31',
      status: 'OPEN',
      lockVersion: 1,
      createdAt: '2026-08-01T00:00:00Z',
      updatedAt: '2026-08-14T00:00:00Z',
      createdBy: 'usr-1',
    };

    // Acme Comp-101: July 2026 (Finalized & Locked)
    const periodJulComp1: AttendancePeriod = {
      id: 'period-comp101-202607',
      companyId: 'comp-101',
      code: 'JUL-2026',
      name: 'July 2026 Attendance Period',
      year: 2026,
      month: 7,
      startDate: '2026-07-01',
      endDate: '2026-07-31',
      status: 'FINALIZED',
      finalizedAt: '2026-08-02T10:00:00Z',
      finalizedBy: 'usr-1',
      finalizedByName: 'Alexander Vance',
      lockVersion: 1,
      createdAt: '2026-07-01T00:00:00Z',
      updatedAt: '2026-08-02T10:00:00Z',
      createdBy: 'usr-1',
    };

    // Nexus Comp-102: August 2026 (Open)
    const periodAugComp2: AttendancePeriod = {
      id: 'period-comp102-202608',
      companyId: 'comp-102',
      code: 'AUG-2026',
      name: 'August 2026 Attendance Period',
      year: 2026,
      month: 8,
      startDate: '2026-08-01',
      endDate: '2026-08-31',
      status: 'OPEN',
      lockVersion: 1,
      createdAt: '2026-08-01T00:00:00Z',
      updatedAt: '2026-08-14T00:00:00Z',
      createdBy: 'usr-1',
    };

    this.attendancePeriods.set(periodAugComp1.id, periodAugComp1);
    this.attendancePeriods.set(periodJulComp1.id, periodJulComp1);
    this.attendancePeriods.set(periodAugComp2.id, periodAugComp2);

    // 16. July 2026 Finalized Summaries for Comp-101
    const julSummaryEmp101: AttendancePeriodSummary = {
      id: 'sum-jul-emp101',
      companyId: 'comp-101',
      periodId: 'period-comp101-202607',
      employeeId: 'emp-101',
      calendarDays: 31,
      scheduledWorkDays: 22,
      presentDays: 22,
      absentDays: 0,
      halfDays: 0,
      weeklyOffDays: 8,
      holidayDays: 1,
      paidLeaveDays: 0,
      unpaidLeaveDays: 0,
      lossOfPayDays: 0,
      payableDays: 31,
      lateArrivalsCount: 0,
      earlyExitsCount: 0,
      totalLateMinutes: 0,
      totalEarlyExitMinutes: 0,
      totalGrossWorkMinutes: 11880,
      totalNetWorkMinutes: 10560,
      calculatedOvertimeMinutes: 120,
      approvedOvertimeMinutes: 120,
      status: 'FINALIZED',
      finalizedAt: '2026-08-02T10:00:00Z',
      createdAt: '2026-08-02T10:00:00Z',
      updatedAt: '2026-08-02T10:00:00Z',
    };

    const julSummaryEmp102: AttendancePeriodSummary = {
      id: 'sum-jul-emp102',
      companyId: 'comp-101',
      periodId: 'period-comp101-202607',
      employeeId: 'emp-102',
      calendarDays: 31,
      scheduledWorkDays: 22,
      presentDays: 21,
      absentDays: 1,
      halfDays: 0,
      weeklyOffDays: 8,
      holidayDays: 1,
      paidLeaveDays: 0,
      unpaidLeaveDays: 0,
      lossOfPayDays: 1,
      payableDays: 30,
      lateArrivalsCount: 1,
      earlyExitsCount: 0,
      totalLateMinutes: 18,
      totalEarlyExitMinutes: 0,
      totalGrossWorkMinutes: 11340,
      totalNetWorkMinutes: 10080,
      calculatedOvertimeMinutes: 0,
      approvedOvertimeMinutes: 0,
      status: 'FINALIZED',
      finalizedAt: '2026-08-02T10:00:00Z',
      createdAt: '2026-08-02T10:00:00Z',
      updatedAt: '2026-08-02T10:00:00Z',
    };

    this.attendancePeriodSummaries.set(julSummaryEmp101.id, julSummaryEmp101);
    this.attendancePeriodSummaries.set(julSummaryEmp102.id, julSummaryEmp102);

    // 17. Sample Overtime Request for Aug 13, 2026 (EMP-101 worked till 20:00, eligible 90m)
    const otReq1: OvertimeRequest = {
      id: 'ot-101-20260813',
      companyId: 'comp-101',
      employeeId: 'emp-101',
      attendanceDate: '2026-08-13',
      dailyAttendanceId: 'da-101-20260813',
      calculatedMinutes: 90,
      requestedMinutes: 90,
      approvedMinutes: 90,
      reason: 'Critical cloud database migration deployment and production release monitoring.',
      status: 'APPROVED',
      approverId: 'emp-103',
      approverComments: 'Approved. Critical release support verified.',
      actionedAt: '2026-08-14T08:30:00Z',
      createdAt: '2026-08-13T20:15:00Z',
      updatedAt: '2026-08-14T08:30:00Z',
      createdBy: 'usr-1',
    };

    this.overtimeRequests.set(otReq1.id, otReq1);

    // Link OT to daily attendance
    const da101Aug13 = this.dailyAttendance.get('da-101-20260813');
    if (da101Aug13) {
      da101Aug13.calculatedOvertimeMinutes = 90;
      da101Aug13.approvedOvertimeMinutes = 90;
      da101Aug13.overtimeRequestId = otReq1.id;
    }
  }

  public rollbackOvertime(companyId: string, employeeId?: string, attendanceDate?: string): void {
    for (const [id, req] of this.overtimeRequests.entries()) {
      if (req.companyId === companyId) {
        if (!employeeId || req.employeeId === employeeId) {
          if (!attendanceDate || req.attendanceDate === attendanceDate) {
            this.overtimeRequests.delete(id);
          }
        }
      }
    }
  }

  public rollbackPeriod(periodId: string): void {
    this.attendancePeriods.delete(periodId);
    for (const [id, s] of this.attendancePeriodSummaries.entries()) {
      if (s.periodId === periodId) {
        this.attendancePeriodSummaries.delete(id);
      }
    }
  }

  public rollbackEmployee(employeeId: string): void {
    this.employees.delete(employeeId);
    for (const [id, a] of this.employeeAssignments.entries()) {
      if (a.employeeId === employeeId) this.employeeAssignments.delete(id);
    }
    for (const [id, addr] of this.employeeAddresses.entries()) {
      if (addr.employeeId === employeeId) this.employeeAddresses.delete(id);
    }
    for (const [id, emg] of this.employeeEmergencyContacts.entries()) {
      if (emg.employeeId === employeeId) this.employeeEmergencyContacts.delete(id);
    }
    for (const [id, b] of this.employeeBankAccounts.entries()) {
      if (b.employeeId === employeeId) this.employeeBankAccounts.delete(id);
    }
    for (const [id, s] of this.employeeStatutoryDetails.entries()) {
      if (s.employeeId === employeeId) this.employeeStatutoryDetails.delete(id);
    }
    for (const [id, d] of this.employeeDocuments.entries()) {
      if (d.employeeId === employeeId) this.employeeDocuments.delete(id);
    }
    for (const [id, h] of this.employeeStatusHistory.entries()) {
      if (h.employeeId === employeeId) this.employeeStatusHistory.delete(id);
    }
    for (const [id, esa] of this.employeeShiftAssignments.entries()) {
      if (esa.employeeId === employeeId) this.employeeShiftAssignments.delete(id);
    }
    for (const [id, r] of this.shiftRosterEntries.entries()) {
      if (r.employeeId === employeeId) this.shiftRosterEntries.delete(id);
    }
    for (const [id, p] of this.attendancePunches.entries()) {
      if (p.employeeId === employeeId) this.attendancePunches.delete(id);
    }
    for (const [id, d] of this.dailyAttendance.entries()) {
      if (d.employeeId === employeeId) this.dailyAttendance.delete(id);
    }
    for (const [id, reg] of this.attendanceRegularizationRequests.entries()) {
      if (reg.employeeId === employeeId) this.attendanceRegularizationRequests.delete(id);
    }
  }

  public rollbackShift(shiftId: string): void {
    this.shifts.delete(shiftId);
    for (const [id, b] of this.shiftBreaks.entries()) {
      if (b.shiftId === shiftId) this.shiftBreaks.delete(id);
    }
    for (const [id, w] of this.weeklyOffRules.entries()) {
      if (w.shiftId === shiftId) this.weeklyOffRules.delete(id);
    }
  }

  public rollbackAttendance(employeeId: string, attendanceDate?: string): void {
    for (const [id, p] of this.attendancePunches.entries()) {
      if (p.employeeId === employeeId) {
        if (!attendanceDate || p.punchTime.startsWith(attendanceDate)) {
          this.attendancePunches.delete(id);
        }
      }
    }
    for (const [id, d] of this.dailyAttendance.entries()) {
      if (d.employeeId === employeeId) {
        if (!attendanceDate || d.attendanceDate === attendanceDate) {
          this.dailyAttendance.delete(id);
        }
      }
    }
    for (const [id, r] of this.attendanceRegularizationRequests.entries()) {
      if (r.employeeId === employeeId) {
        if (!attendanceDate || r.attendanceDate === attendanceDate) {
          this.attendanceRegularizationRequests.delete(id);
        }
      }
    }
  }
}
