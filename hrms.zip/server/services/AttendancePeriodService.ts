import {
  AttendancePeriod,
  AttendancePeriodSummary,
  AttendancePeriodReviewReport,
  FinalizationBlocker,
  CreatePeriodDTO,
  FinalizePeriodDTO,
  ReopenPeriodDTO,
} from '../../src/types/period.js';
import { AuthUser, UserRole, PermissionKey } from '../../src/types/auth.js';
import { RelationalDatabase } from '../database/RelationalDatabase.js';
import { AttendancePeriodRepository } from '../database/repositories/AttendancePeriodRepository.js';
import { AttendancePeriodSummaryRepository } from '../database/repositories/AttendancePeriodSummaryRepository.js';
import { DailyAttendanceRepository } from '../database/repositories/DailyAttendanceRepository.js';
import { AttendanceRegularizationRepository } from '../database/repositories/AttendanceRegularizationRepository.js';
import { OvertimeRequestRepository } from '../database/repositories/OvertimeRequestRepository.js';
import { AuditService } from './AuditService.js';

export class AttendancePeriodService {
  private static db = RelationalDatabase.getInstance();

  /**
   * Check if a specific date in a company is inside a locked/finalized attendance period
   */
  public static async isDateLocked(companyId: string, date: string): Promise<boolean> {
    const period = await AttendancePeriodRepository.findByDate(companyId, date);
    if (!period) return false;
    return period.status === 'FINALIZED' || period.status === 'LOCKED';
  }

  /**
   * 1. Get or Create Attendance Period for a month
   */
  public static async getOrCreatePeriod(
    companyId: string,
    year: number,
    month: number,
    actor?: AuthUser
  ): Promise<AttendancePeriod> {
    let period = await AttendancePeriodRepository.findByYearMonth(companyId, year, month);
    if (period) return period;

    const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
    const lastDay = new Date(year, month, 0).getDate();
    const endDate = `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
    
    const monthNames = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    const monthName = monthNames[month - 1];
    const code = `${monthName.substring(0, 3).toUpperCase()}-${year}`;
    const name = `${monthName} ${year} Attendance Period`;
    const id = `period-${companyId}-${year}${String(month).padStart(2, '0')}`;

    const newPeriod: AttendancePeriod = {
      id,
      companyId,
      code,
      name,
      year,
      month,
      startDate,
      endDate,
      status: 'OPEN',
      lockVersion: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: actor?.id || 'system',
    };

    const saved = await AttendancePeriodRepository.create(newPeriod);

    if (actor) {
      await AuditService.log({
        companyId,
        actorId: actor.id,
        actorName: actor.fullName,
        actorEmail: actor.email,
        action: 'ATTENDANCE_PERIOD_CREATED',
        targetModule: 'ATTENDANCE',
        targetRecordId: saved.id,
        changesSummary: `Created attendance period ${saved.name} (${saved.startDate} to ${saved.endDate})`,
        newValue: saved,
      });
    }

    return saved;
  }

  /**
   * 2. Gather Period Review Report & Blockers
   */
  public static async getPeriodReviewReport(
    companyId: string,
    periodId: string,
    actor: AuthUser
  ): Promise<AttendancePeriodReviewReport> {
    const period = await AttendancePeriodRepository.findById(periodId, companyId);
    if (!period) {
      throw new Error('ATTENDANCE_PERIOD_NOT_FOUND: Attendance period not found');
    }

    // Get active employees for company
    const employees = Array.from(this.db.employees.values()).filter(
      (e) => e.companyId === companyId && e.status === 'ACTIVE'
    );

    // Get all daily attendance records for this period
    const dailyRecords = await DailyAttendanceRepository.findAll(companyId, {
      startDate: period.startDate,
      endDate: period.endDate,
    });

    // Check for blockers:
    const blockers: FinalizationBlocker[] = [];

    // 1. Missing punches / Incomplete days
    const incompleteDays = dailyRecords.filter((d) => d.status === 'INCOMPLETE' || d.hasException);
    const missingPunchDays = dailyRecords.filter(
      (d) => d.status === 'INCOMPLETE' || (d.firstCheckIn && !d.lastCheckOut)
    );

    if (missingPunchDays.length > 0) {
      blockers.push({
        type: 'MISSING_PUNCH',
        count: missingPunchDays.length,
        message: `${missingPunchDays.length} daily attendance records have missing punch-outs or incomplete state.`,
        details: missingPunchDays.slice(0, 10).map((d) => ({
          id: d.id,
          employeeId: d.employeeId,
          employeeCode: d.employeeCode,
          employeeName: d.displayName,
          date: d.attendanceDate,
          description: `Missing check-out on ${d.attendanceDate} (Shift: ${d.shiftName || 'Standard'})`,
        })),
      });
    }

    // 2. Pending Regularizations
    const pendingRegularizations = Array.from(this.db.attendanceRegularizationRequests.values()).filter(
      (r) =>
        r.companyId === companyId &&
        r.status === 'PENDING' &&
        r.attendanceDate >= period.startDate &&
        r.attendanceDate <= period.endDate
    );

    if (pendingRegularizations.length > 0) {
      blockers.push({
        type: 'PENDING_REGULARIZATION',
        count: pendingRegularizations.length,
        message: `${pendingRegularizations.length} attendance regularization requests are pending approval.`,
        details: pendingRegularizations.slice(0, 10).map((r) => {
          const emp = this.db.employees.get(r.employeeId);
          return {
            id: r.id,
            employeeId: r.employeeId,
            employeeCode: emp?.employeeCode,
            employeeName: emp?.displayName,
            date: r.attendanceDate,
            description: `Regularization requested: ${r.reason} (${r.requestedCheckIn || ''} - ${r.requestedCheckOut || ''})`,
          };
        }),
      });
    }

    // 3. Pending Overtime Requests
    const pendingOtRequests = Array.from(this.db.overtimeRequests.values()).filter(
      (r) =>
        r.companyId === companyId &&
        r.status === 'PENDING' &&
        r.attendanceDate >= period.startDate &&
        r.attendanceDate <= period.endDate
    );

    if (pendingOtRequests.length > 0) {
      blockers.push({
        type: 'PENDING_OVERTIME',
        count: pendingOtRequests.length,
        message: `${pendingOtRequests.length} overtime requests are pending managerial approval.`,
        details: pendingOtRequests.slice(0, 10).map((r) => {
          const emp = this.db.employees.get(r.employeeId);
          return {
            id: r.id,
            employeeId: r.employeeId,
            employeeCode: emp?.employeeCode,
            employeeName: emp?.displayName,
            date: r.attendanceDate,
            description: `Overtime requested: ${r.requestedMinutes} mins on ${r.attendanceDate} (${r.reason})`,
          };
        }),
      });
    }

    // Calculate aggregated metrics across daily records
    let totalPresentDays = 0;
    let totalAbsentDays = 0;
    let totalHalfDays = 0;
    let totalWeeklyOffDays = 0;
    let totalHolidayDays = 0;
    let totalCalculatedOt = 0;
    let totalApprovedOt = 0;

    for (const d of dailyRecords) {
      if (d.status === 'PRESENT' || d.status === 'REGULARIZED') totalPresentDays += 1;
      else if (d.status === 'HALF_DAY') {
        totalHalfDays += 1;
        totalPresentDays += 0.5;
        totalAbsentDays += 0.5;
      } else if (d.status === 'ABSENT' || d.status === 'INCOMPLETE') {
        totalAbsentDays += 1;
      } else if (d.status === 'WEEKLY_OFF') {
        totalWeeklyOffDays += 1;
      } else if (d.status === 'HOLIDAY') {
        totalHolidayDays += 1;
      }

      if (d.calculatedOvertimeMinutes) totalCalculatedOt += d.calculatedOvertimeMinutes;
      if (d.approvedOvertimeMinutes) totalApprovedOt += d.approvedOvertimeMinutes;
    }

    // Generate or fetch summaries
    let summaries: AttendancePeriodSummary[] = [];
    if (period.status === 'FINALIZED' || period.status === 'LOCKED') {
      summaries = await AttendancePeriodSummaryRepository.findByPeriodId(period.id, companyId);
    } else {
      summaries = await this.computeDraftSummaries(companyId, period, employees);
    }

    const lastDayOfMonth = new Date(period.year, period.month, 0).getDate();

    return {
      period,
      metrics: {
        totalEmployees: employees.length,
        calendarDays: lastDayOfMonth,
        presentDays: totalPresentDays,
        absentDays: totalAbsentDays,
        halfDays: totalHalfDays,
        weeklyOffDays: totalWeeklyOffDays,
        holidayDays: totalHolidayDays,
        paidLeaveDays: 0,
        missingPunchesCount: missingPunchDays.length,
        pendingRegularizationsCount: pendingRegularizations.length,
        pendingOvertimeCount: pendingOtRequests.length,
        exceptionsCount: incompleteDays.length,
        totalApprovedOvertimeMinutes: totalApprovedOt,
        totalApprovedOvertimeHours: Number((totalApprovedOt / 60).toFixed(1)),
        isFinalizable: blockers.length === 0,
      },
      blockers,
      summaries,
    };
  }

  /**
   * 3. Finalize Attendance Period (Atomic, Concurrency-Safe, Idempotent)
   */
  public static async finalizePeriod(
    companyId: string,
    actor: AuthUser,
    dto: FinalizePeriodDTO
  ): Promise<AttendancePeriod> {
    // 1. Permission check
    const canFinalize =
      actor.role === UserRole.SUPER_ADMIN ||
      actor.role === UserRole.HR_ADMIN ||
      actor.role === UserRole.PAYROLL_MANAGER ||
      actor.permissions.includes(PermissionKey.ATTENDANCE_PERIOD_FINALIZE);

    if (!canFinalize) {
      throw new Error('FORBIDDEN: You do not have permission to finalize attendance periods.');
    }

    // 2. Fetch period and verify state
    const period = await AttendancePeriodRepository.findById(dto.periodId, companyId);
    if (!period) {
      throw new Error('ATTENDANCE_PERIOD_NOT_FOUND: Attendance period not found');
    }

    // Idempotency: If already finalized, return existing finalized record
    if (period.status === 'FINALIZED' || period.status === 'LOCKED') {
      return period;
    }

    // 3. Review validation & blocker enforcement
    const report = await this.getPeriodReviewReport(companyId, period.id, actor);
    if (report.blockers.length > 0 && !dto.forceFinalize) {
      const blockerMessages = report.blockers.map((b) => b.message).join(' | ');
      throw new Error(`ATTENDANCE_PERIOD_HAS_BLOCKERS: Cannot finalize period. Unresolved issues: ${blockerMessages}`);
    }

    // 4. Begin transactional materialization
    const employees = Array.from(this.db.employees.values()).filter(
      (e) => e.companyId === companyId && e.status === 'ACTIVE'
    );

    const summariesToSave = await this.computeDraftSummaries(companyId, period, employees, 'FINALIZED');

    // Save summaries
    await AttendancePeriodSummaryRepository.saveBatch(summariesToSave);

    // Update period status to FINALIZED
    const finalized = await AttendancePeriodRepository.update(period.id, companyId, {
      status: 'FINALIZED',
      finalizedAt: new Date().toISOString(),
      finalizedBy: actor.id,
      lockVersion: period.lockVersion + 1,
    });

    if (!finalized) throw new Error('Failed to update attendance period status');

    // Audit Log
    await AuditService.log({
      companyId,
      actorId: actor.id,
      actorName: actor.fullName,
      actorEmail: actor.email,
      action: 'ATTENDANCE_PERIOD_FINALIZED',
      targetModule: 'ATTENDANCE',
      targetRecordId: finalized.id,
      changesSummary: `Finalized attendance period ${finalized.name}. Materialized ${summariesToSave.length} payroll summaries.`,
      previousValue: period,
      newValue: finalized,
    });

    return finalized;
  }

  /**
   * 4. Controlled Reopen Attendance Period
   */
  public static async reopenPeriod(
    companyId: string,
    actor: AuthUser,
    dto: ReopenPeriodDTO
  ): Promise<AttendancePeriod> {
    // 1. Strict permission check
    const canReopen =
      actor.role === UserRole.SUPER_ADMIN ||
      actor.role === UserRole.HR_ADMIN ||
      actor.permissions.includes(PermissionKey.ATTENDANCE_PERIOD_REOPEN);

    if (!canReopen) {
      throw new Error('FORBIDDEN: You do not have permission to reopen a finalized attendance period.');
    }

    if (!dto.reason || dto.reason.trim().length < 10) {
      throw new Error('VALIDATION_ERROR: A detailed reason (at least 10 characters) is required to reopen a period.');
    }

    const period = await AttendancePeriodRepository.findById(dto.periodId, companyId);
    if (!period) {
      throw new Error('ATTENDANCE_PERIOD_NOT_FOUND: Attendance period not found');
    }

    if (period.status !== 'FINALIZED' && period.status !== 'LOCKED') {
      throw new Error('VALIDATION_ERROR: Period is not in finalized state.');
    }

    const reopened = await AttendancePeriodRepository.update(period.id, companyId, {
      status: 'OPEN',
      reopenedAt: new Date().toISOString(),
      reopenedBy: actor.id,
      reopenReason: dto.reason.trim(),
      lockVersion: period.lockVersion + 1,
    });

    if (!reopened) throw new Error('Failed to reopen attendance period');

    // Audit Log
    await AuditService.log({
      companyId,
      actorId: actor.id,
      actorName: actor.fullName,
      actorEmail: actor.email,
      action: 'ATTENDANCE_PERIOD_REOPENED',
      targetModule: 'ATTENDANCE',
      targetRecordId: reopened.id,
      changesSummary: `Reopened attendance period ${reopened.name}. Reason: ${dto.reason.trim()}`,
      previousValue: period,
      newValue: reopened,
    });

    return reopened;
  }

  /**
   * 5. Get Payroll-Ready Summaries for a Period
   */
  public static async getPeriodSummaries(
    companyId: string,
    periodId: string,
    actor: AuthUser
  ): Promise<AttendancePeriodSummary[]> {
    const period = await AttendancePeriodRepository.findById(periodId, companyId);
    if (!period) {
      throw new Error('ATTENDANCE_PERIOD_NOT_FOUND: Attendance period not found');
    }

    if (period.status === 'FINALIZED' || period.status === 'LOCKED') {
      return AttendancePeriodSummaryRepository.findByPeriodId(periodId, companyId);
    } else {
      const employees = Array.from(this.db.employees.values()).filter(
        (e) => e.companyId === companyId && e.status === 'ACTIVE'
      );
      return this.computeDraftSummaries(companyId, period, employees, 'DRAFT');
    }
  }

  /**
   * Compute normalized draft/finalized summaries for employees over a period
   */
  private static async computeDraftSummaries(
    companyId: string,
    period: AttendancePeriod,
    employees: any[],
    status: 'DRAFT' | 'FINALIZED' = 'DRAFT'
  ): Promise<AttendancePeriodSummary[]> {
    const lastDayOfMonth = new Date(period.year, period.month, 0).getDate();
    const summaries: AttendancePeriodSummary[] = [];

    for (const emp of employees) {
      const dailyRecords = await DailyAttendanceRepository.findAll(companyId, {
        employeeId: emp.id,
        startDate: period.startDate,
        endDate: period.endDate,
      });

      let presentDays = 0;
      let absentDays = 0;
      let halfDays = 0;
      let weeklyOffDays = 0;
      let holidayDays = 0;
      let lateArrivalsCount = 0;
      let earlyExitsCount = 0;
      let totalLateMinutes = 0;
      let totalEarlyExitMinutes = 0;
      let totalGrossWorkMinutes = 0;
      let totalNetWorkMinutes = 0;
      let calculatedOvertimeMinutes = 0;
      let approvedOvertimeMinutes = 0;

      for (const d of dailyRecords) {
        if (d.status === 'PRESENT' || d.status === 'REGULARIZED') {
          presentDays += 1;
        } else if (d.status === 'HALF_DAY') {
          halfDays += 1;
          presentDays += 0.5;
          absentDays += 0.5;
        } else if (d.status === 'ABSENT' || d.status === 'INCOMPLETE') {
          absentDays += 1;
        } else if (d.status === 'WEEKLY_OFF') {
          weeklyOffDays += 1;
        } else if (d.status === 'HOLIDAY') {
          holidayDays += 1;
        }

        if (d.isLateArrival) {
          lateArrivalsCount += 1;
          totalLateMinutes += d.lateMinutes || 0;
        }
        if (d.isEarlyExit) {
          earlyExitsCount += 1;
          totalEarlyExitMinutes += d.earlyExitMinutes || 0;
        }

        totalGrossWorkMinutes += d.grossWorkMinutes || 0;
        totalNetWorkMinutes += d.netWorkMinutes || 0;

        if (d.calculatedOvertimeMinutes) calculatedOvertimeMinutes += d.calculatedOvertimeMinutes;
        if (d.approvedOvertimeMinutes) approvedOvertimeMinutes += d.approvedOvertimeMinutes;
      }

      // Scheduled work days = calendar days - weekly offs - holidays
      const scheduledWorkDays = Math.max(0, lastDayOfMonth - weeklyOffDays - holidayDays);
      const lossOfPayDays = absentDays;
      const payableDays = presentDays + weeklyOffDays + holidayDays;

      const summaryId = `sum-${period.id}-${emp.id}`;
      summaries.push({
        id: summaryId,
        companyId,
        periodId: period.id,
        employeeId: emp.id,
        calendarDays: lastDayOfMonth,
        scheduledWorkDays,
        presentDays,
        absentDays,
        halfDays,
        weeklyOffDays,
        holidayDays,
        paidLeaveDays: 0,
        unpaidLeaveDays: 0,
        lossOfPayDays,
        payableDays,
        lateArrivalsCount,
        earlyExitsCount,
        totalLateMinutes,
        totalEarlyExitMinutes,
        totalGrossWorkMinutes,
        totalNetWorkMinutes,
        calculatedOvertimeMinutes,
        approvedOvertimeMinutes,
        status,
        finalizedAt: status === 'FINALIZED' ? new Date().toISOString() : undefined,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        employeeCode: emp.employeeCode,
        displayName: emp.displayName || `${emp.firstName} ${emp.lastName}`,
        employeeName: emp.displayName || `${emp.firstName} ${emp.lastName}`,
        avatarUrl: emp.avatarUrl,
      });
    }

    return summaries;
  }
}
